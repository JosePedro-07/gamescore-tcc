<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GameScore</title>
  <link rel="stylesheet" href="css/style_geral.css" />
  <link rel="stylesheet" href="css/style_editar_perfil.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="icon" href="imagens/controle_top.png" type="image/png" />
</head>
<body>

  <?php include "php/pesquisausUid.php";?>

  <header>
    <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      <img src="imagens/controle_ret.png" alt="Ícone de controle de videogame" class="logo-pequena" />
    </a>
    <h1>
      <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
        <img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" />
      </a>
    </h1>

    <div class="header-opcoes">
      <div class="usuario-logado" id="usuarioLogado">
        <div class="avatar-usuario"><?= $primeiraLetra ?></div>
        <span class="nome-usuario">
          <?php
            if ($tipo == 0):
              echo " Olá, " . htmlspecialchars($nickname);
            elseif ($tipo == 1):
              echo " Olá Admin, " . htmlspecialchars($nickname);
            elseif ($tipo == 2):
              echo " Olá Moderador, " . htmlspecialchars($nickname);
            endif;
          ?>
        </span>
  
        <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
          <?php if ($tipo == 1): // ADMIN ?>
            <button role="menuitem" onclick="cadastrarModera(<?= $idusu ?>)">Cadastrar Moderador</button>
            <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php elseif ($tipo == 2): // MODERADOR ?>
            
            <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php endif; ?>
          <button role="menuitem" onclick="gerenciarResenhas(<?= $idusu ?>)">Gerenciar Resenhas</button>
          <button role="menuitem" onclick="window.location.href='php/logout.php'">Sair</button>
        </div>
      </div>
    </div>
  </header>

  <main>
    <button id="btnVoltar" role="menuitem" onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      ← Voltar
    </button>

    <h1>Editar Perfil</h1>
    
    <form id="editarPerfilForm" onsubmit="event.preventDefault();">
      <input type="hidden" name="idusu" value="<?= $idusu ?>">
      <div>
        
      <!-- INCLUA OS CAMPOS DO FORMULÁRIO AQUI -->
      <?php include "php/pesquisarUsuarioEdt.php"; ?>

      <button type="submit" id="BotaoSalvarAlt">Salvar Alterações</button>
    </form>

    <div id="mensagem" style="display: none; color: white; text-align: center; margin-top: 15px;"></div>
  </main>

  <!-- SCRIPTS -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="js/script.js"></script>
  <script src="js/script_edtperfil.js"></script>
  <script src="js/script_carrossel.js"></script>

  <script>
    // Preview da imagem
    const capaInput = document.getElementById("capa");
    const preview = document.getElementById("previewCapa");

    capaInput.addEventListener("change", () => {
      const file = capaInput.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = e => {
          preview.innerHTML = `<img src="${e.target.result}" alt="Pré-visualização da capa" style="max-width:200px;border-radius:8px;">`;
        };
        reader.readAsDataURL(file);
      } else {
        preview.innerHTML = "";
      }
    });

    // Formatação do telefone
    document.getElementById('telefoneEdt').addEventListener('input', function (e) {
      let telefone = e.target.value.replace(/\D/g, '');

      if (telefone.length > 11) {
        telefone = telefone.substring(0, 11);
      }

      if (telefone.length > 10) {
        telefone = telefone.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
      } else if (telefone.length > 6) {
        telefone = telefone.replace(/^(\d{2})(\d{4})(\d{0,4})$/, '($1) $2-$3');
      } else if (telefone.length > 2) {
        telefone = telefone.replace(/^(\d{2})(\d{0,5})$/, '($1) $2');
      } else {
        telefone = telefone.replace(/^(\d*)$/, '($1');
      }

      e.target.value = telefone;
    });
  </script>
</body>
</html>