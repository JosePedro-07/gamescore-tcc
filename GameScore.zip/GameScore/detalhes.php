<?php
// pesquisar avaliações
include "php/pesquisaAvaDt.php";

/* 1 - incluir a conexão */
include "php/conexao.php";

/* 2 - inicializar variáveis */
$idusu = null;
$nickname = null;
$tipo = null;
$primeiraLetra = null;
$erroDetalhes = '';
$jogoNome = '';
$jogoImagem = '';
$jogoDescricao = '';

$avaliacoes = [];

/* 3 - Pegar appId da URL (padronizado: appId) */
$appIdParam = $_GET['appId'] ?? null;
$appId = is_numeric($appIdParam) ? intval($appIdParam) : null;

/* 4 - Buscar avaliações no banco */
if ($appId) {
    $comandoSql = "
        SELECT a.RECOMENDACAO, a.AVALIACAO, u.NICKNAME
        FROM tbavaliacao a
        JOIN tbusuario u ON a.CODUSUARIO = u.idusu
        WHERE a.CODJOGO = $appId
    ";
    $result = $conn->query($comandoSql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $avaliacoes[] = $row;
        }
    }
}

/* 5 - verificar se existe o parâmetro idusu na URL */
if (isset($_GET["idusu"]) && is_numeric($_GET["idusu"])) {
    $idusu = intval($_GET["idusu"]);

    $comandoSql = "SELECT NICKNAME, TIPOUSUARIO FROM tbusuario WHERE idusu=$idusu";
    $result = $conn->query($comandoSql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nickname = $row["NICKNAME"];
        $tipo = $row["TIPOUSUARIO"];
        $primeiraLetra = $nickname ? strtoupper(mb_substr($nickname, 0, 1)) : '';
    }
}

/* 6 - Função para buscar detalhes do app na API da Steam */
function steam_fetch_app_details($appId, $lang = 'portuguese') {
    $url = "https://store.steampowered.com/api/appdetails?appids=" . urlencode($appId) . "&l=" . urlencode($lang);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 12,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) GameScoreBot/1.0',
        CURLOPT_SSL_VERIFYPEER => false, // fallback para ambientes locais
        CURLOPT_SSL_VERIFYHOST => 0,
    ]);

    $resp = curl_exec($ch);
    if ($resp === false) {
        curl_close($ch);
        return null;
    }
    $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    if ($status < 200 || $status >= 300) {
        return null;
    }

    $json = json_decode($resp, true);
    if (!is_array($json) || !isset($json[$appId])) {
        return null;
    }

    $entry = $json[$appId];
    if (!isset($entry['success']) || !$entry['success'] || !isset($entry['data']) || !is_array($entry['data'])) {
        return null;
    }

    $data = $entry['data'];
    return [
        'id' => (int)$appId,
        'nome' => $data['name'] ?? '',
        'imagem' => $data['header_image'] ?? '',
        'descricao' => $data['short_description'] ?? '',
    ];
}

/* 7 - Buscar detalhes do jogo na Steam */
if ($appId) {
    $detalhes = steam_fetch_app_details($appId);
    if ($detalhes) {
        $jogoNome = $detalhes['nome'];
        $jogoImagem = $detalhes['imagem'];
        $jogoDescricao = $detalhes['descricao'];
    } else {
        $erroDetalhes = "Não foi possível carregar os detalhes do jogo.";
    }
} else {
    $erroDetalhes = "ID do jogo inválido.";
}

/* 8 - Verificar se o jogo já está cadastrado no banco e inserir se não estiver */
if ($appId && $detalhes) {
    // Verifica se já existe pelo AppId
    $stmt = $conn->prepare("SELECT AppId FROM tbjogo WHERE AppId = ?");
    if (!$stmt) {
        die("Erro no prepare SELECT: " . $conn->error);
    }
    $stmt->bind_param("i", $appId);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        // Não existe, então insere
        $stmtInsert = $conn->prepare("
            INSERT INTO tbjogo (AppId, NomeJogo) 
            VALUES (?, ?)
        ");
        if (!$stmtInsert) {
            die("Erro no prepare INSERT: " . $conn->error);
        }
        $stmtInsert->bind_param(
            "is",
            $detalhes['id'],   // AppId
            $detalhes['nome']  // Nome do jogo
        );
        if (!$stmtInsert->execute()) {
            die("Erro ao inserir jogo: " . $stmtInsert->error);
        }
        $stmtInsert->close();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GameScore - <?= htmlspecialchars($jogoNome) ?></title>
  <link rel="stylesheet" href="css/style_geral.css"/>
  <link rel="stylesheet" href="css/style_detalhes.css"/>
  <link rel="stylesheet" href="css/style_indexDeslogado.css"/>  
  <link rel="icon" href="imagens/controle_top.png" type="image/png">
</head>
<body>

<header>
  <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
    <img src="imagens/controle_ret.png" alt="Ícone de controle" class="logo-pequena" />
  </a>
  <h1>
    <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      <img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" />
    </a>
  </h1>

  <div class="header-opcoes">
    <?php if (!empty($idusu)): ?>
      <div class="usuario-logado" id="usuarioLogado">
        <div class="avatar-usuario"><?= htmlspecialchars($primeiraLetra) ?></div>
        <span class="nome-usuario">
          <?php
            if ($tipo == 0) {
              echo "Olá, " . htmlspecialchars($nickname);
            } elseif ($tipo == 1) {
              echo "Olá Admin, " . htmlspecialchars($nickname);
            } elseif ($tipo == 2) {
              echo "Olá Moderador, " . htmlspecialchars($nickname);
            }
          ?>
        </span>
        <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
          <?php if ($tipo == 1): ?>
            <button onclick="cadastrarModera(<?= (int)$idusu ?>)">Cadastrar Moderador</button>
            <button onclick="gerenciarResenhasGerais(<?= (int)$idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php elseif ($tipo == 2): ?>
            <button onclick="gerenciarResenhasGerais(<?= (int)$idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php endif; ?>
          <button onclick="gerenciarResenhas(<?= (int)$idusu ?>)">Gerenciar Resenhas</button>
          <button onclick="editarPerfil(<?= (int)$idusu ?>)">Editar Perfil</button>
          <button onclick="window.location.href='php/logout.php'">Sair</button>
        </div>
      </div>
    <?php else: ?>
      <div class="usuario-logado">
        <button onclick="window.location.href='login.html'" class="botao-login">Fazer Login</button>
      </div>
    <?php endif; ?>
  </div>
</header>

<main>
  <div class="detalhes-container">
    <img id="imagem-jogo" 
         src="<?= htmlspecialchars($jogoImagem) ?>" 
         alt="<?= $jogoNome ? 'Capa de ' . htmlspecialchars($jogoNome) : 'Imagem do jogo' ?>" />

    <aside class="avaliacoes-usuarios" id="avaliacoes-usuarios">
      <h3>Avaliações dos usuários</h3>
      <?php if (!empty($avaliacoes)): ?>
        <?php foreach ($avaliacoes as $av): ?>
          <div class="avaliacao-usuario">
            <?php
              $estrelas = str_repeat("★", (int)$av["AVALIACAO"]) . str_repeat("☆", 5 - (int)$av["AVALIACAO"]);
            ?>
            <div class="estrelas"><?= $estrelas ?></div>
            <p><strong><?= htmlspecialchars($av["NICKNAME"]) ?>:</strong> <?= htmlspecialchars($av["RECOMENDACAO"]) ?></p>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p>Nenhuma avaliação encontrada para este jogo.</p>
      <?php endif; ?>
    </aside>

    <div class="descricao-jogo">
      <?php if (!empty($erroDetalhes)): ?>
        <p><?= htmlspecialchars($erroDetalhes) ?></p>
      <?php else: ?>
        <?php if (!empty($jogoNome)): ?>
          <h2><?= htmlspecialchars($jogoNome) ?></h2>
        <?php endif; ?>
        <?php if (!empty($jogoDescricao)): ?>
          <p><?= nl2br(htmlspecialchars($jogoDescricao)) ?></p>
        <?php endif; ?>
      <?php endif; ?>
    </div>

    <?php if ($idusu !== null && $idusu > 0): ?>
    <div class="avaliacao">
      <form id="avaliacaoForm" onsubmit="event.preventDefault();">
        <h2>Deixe sua avaliação</h2>
        
        <div id="mensagem"></div>
        <!-- SISTEMA DE ESTRELAS ATUALIZADO -->
        <div class="input-group">
          <div id="rating" class="stars">
            <span data-value="1">☆</span>
            <span data-value="2">☆</span>
            <span data-value="3">☆</span>
            <span data-value="4">☆</span>
            <span data-value="5">☆</span>
          </div>
          <input type="hidden" id="Avaliacao" name="Avaliacao" value="0">
        </div>

        <textarea id="comentario" name="comentario" maxlength="500" placeholder="Digite sua opinião..." required></textarea>

        <div class="botoes-avaliacao">
          <button class="button" id="BotaoSalvarAvaliacao" type="submit">Enviar Avaliação</button>
          <button type="button" class="button btn-voltar" onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">Voltar</button>
        </div>
      </form>
    </div>
    <?php endif; ?>

  </div>

</main>

<script>
// Passa os valores do PHP para o JS
const appId = <?= (int)$appId ?>;
const idusu = <?= (int)$idusu ?>;

// Sistema de estrelas - MESMO CÓDIGO DO EDITAR_RESENHA
document.addEventListener('DOMContentLoaded', function() {
    // Configurar eventos das estrelas
    const stars = document.querySelectorAll('#rating span');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            const value = parseInt(this.getAttribute('data-value'));
            document.getElementById('Avaliacao').value = value;
            pintarEstrelas(value);
        });
        
        star.addEventListener('mouseover', function() {
            const value = parseInt(this.getAttribute('data-value'));
            pintarEstrelas(value);
        });
        
        star.addEventListener('mouseout', function() {
            const currentValue = parseInt(document.getElementById('Avaliacao').value);
            pintarEstrelas(currentValue);
        });
    });
});

function pintarEstrelas(valor) {
    const stars = document.querySelectorAll('#rating span');
    stars.forEach((star, index) => {
        if (index < valor) {
            star.textContent = '★';
            star.style.color = '#ffcc00';
        } else {
            star.textContent = '☆';
            star.style.color = '#ccc';
        }
    });
}

// Funções do menu
function cadastrarModera(idusu) {
    window.location.href = 'cadastro_modera.php?idusu=' + idusu;
}

function cadastrarJogo(idusu) {
    window.location.href = 'cadastro_jogo.php?idusu=' + idusu;
}

function gerenciarResenhasGerais(idusu) {
    window.location.href = 'gerenciar_resenhas_gerais.php?idusu=' + idusu;
}

function gerenciarResenhas(idusu) {
    window.location.href = 'gerenciar_resenhas.php?idusu=' + idusu;
}

function editarPerfil(idusu) {
    window.location.href = 'editar_perfil.php?idusu=' + idusu;
}
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/script_avaliar.js"></script>
<script src="js/script.js"></script>
<script src="js/script_carrossel.js"></script>

</body>
</html>