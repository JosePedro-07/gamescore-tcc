<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GameScore</title>
  <link rel="stylesheet" href="css/style_geral.css"/>
  <link rel="stylesheet" href="css/style_cadastro_modera.css"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="icon" href="imagens/controle_top.png" type="image/png">
</head>
<body>

  <?php include "php/pesquisausUid.php";?>

<header>
<a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      <img src="imagens/controle_ret.png" alt="Ícone de controle de videogame" class="logo-pequena" />
    </a>
    <h1>
      <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
        <img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" />
      </a>
    </h1>


  <div class="header-opcoes">

<div class="usuario-logado" id="usuarioLogado">
    <div class="avatar-usuario"><?= $primeiraLetra ?></div>
    <span class="nome-usuario">
      <?php
        if ($tipo == 0):
          echo " Olá, " . htmlspecialchars($nickname);
        elseif ($tipo == 1):
          echo " Olá Admin, " . htmlspecialchars($nickname);
        elseif ($tipo == 2):
          echo " Olá Moderador, " . htmlspecialchars($nickname);
        endif;?>
        </span>
  
  <!-- Botões divididos por tipo de usuario-->
  <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
            <?php if ($tipo == 1): // ADMIN ?>
              <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
            <?php elseif ($tipo == 2): // MODERADOR ?>
              <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
            <?php endif; ?>

            <!-- Botões comuns a todos os usuários logados -->
            <button role="menuitem" onclick="gerenciarResenhas(<?= $idusu ?>)">Gerenciar Resenhas</button>
            <button role="menuitem" onclick="editarPerfil(<?= $idusu ?>)">Editar Perfil</button>
            <button role="menuitem" onclick="window.location.href='php/logout.php'">Sair</button>
          </div>
        </div>

      
    </div>
  </header>

<div class="login-body">
  <main class="login-box" role="main" aria-label="Formulário de cadastro">  
    <button id="btnVoltar" role="menuitem" onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      ← Voltar
    </button>
    <h1>Cadastro Moderador</h1>
    <h2>GameScore</h2>

    <form id="formCadastroMod" method="post" onsubmit="event.preventDefault();">
      <div class="input-group">
      <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zM12 14c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
        <input type="text" id="nomemod" name="nomemod" placeholder="Nome Completo" required>
      </div>

      <div class="input-group">
      <svg viewBox="0 0 24 24"><path d="M16 11c1.66 0 3-1.34 3-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 3-1.34 3-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
        <input type="text" id="nickmod" name="nickmod" placeholder="Nickname" required>
      </div>

      <div class="input-group">
      <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4-8 5-8-5V6l8 5 8-5v2z"/></svg>
        <input type="email" id="emailmod" name="emailMod" placeholder="Email" required>
      </div>

      <div class="input-group">
      <svg viewBox="0 0 24 24"><path d="M6.62 10.79a15.91 15.91 0 0 0 6.59 6.59l2.2-2.2a1.003 1.003 0 0 1 1.11-.21c1.21.49 2.53.76 3.89.76.55 0 1 .45 1 1V20a1 1 0 0 1-1 1C10.07 21 3 13.93 3 5a1 1 0 0 1 1-1h3.5c.55 0 1 .45 1 1 0 1.36.27 2.68.76 3.89a1.003 1.003 0 0 1-.21 1.11l-2.2 2.2z"/></svg>
        <input type="tel" id="telmod" name="telmod" placeholder="Telefone" required>
      </div>

      <div>
        <div class="input-group senha-group">
            <input type="password" id="senhamod" name="senhamod" placeholder="Senha" maxlength="25" />
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 17a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm6-7v6a6 6 0 1 1-12 0v-6a3 3 0 0 1 6 0z"/></svg>
            <button type="button" class="toggle-senha" onclick="toggleSenha('senhamod', this)" aria-label="Mostrar ou ocultar senha">
                <img src="imagens/mostrar.png" alt="Mostrar senha" class="icone-olho">
            </button>
        </div>
    </div>

      <button type="submit" class="login-btn" id="BotaoCadastraMod">Cadastrar</button>
    </form>
    <div id="mensagem" style="display: none; color: white; text-align: center; margin-top: 15px;"></div>
  </main>
</div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/script_mod.js"></script>
<script src="js/script.js"></script>
<script src="js/script_carrossel.js"></script>

<script>
    // Formatação do telefone
    document.getElementById('telmod').addEventListener('input', function (e) {
      let telefone = e.target.value.replace(/\D/g, '');

      if (telefone.length > 11) {
        telefone = telefone.substring(0, 11);
      }

      if (telefone.length > 10) {
        telefone = telefone.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
      } else if (telefone.length > 6) {
        telefone = telefone.replace(/^(\d{2})(\d{4})(\d{0,4})$/, '($1) $2-$3');
      } else if (telefone.length > 2) {
        telefone = telefone.replace(/^(\d{2})(\d{0,5})$/, '($1) $2');
      } else {
        telefone = telefone.replace(/^(\d*)$/, '($1');
      }

      e.target.value = telefone;
    });

  </script>

</body>
</html>
