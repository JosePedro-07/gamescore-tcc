<?php
include "php/conexao.php";
include "php/pesquisausuid.php";

$avaliacoes = [];

// ✅ CONSULTA CORRIGIDA - Use AppId no JOIN
$sql = "
  SELECT a.IDAVA, a.RECOMENDACAO, a.AVALIACAO,
         j.NOMEJOGO, u.NICKNAME
  FROM tbavaliacao a
  JOIN tbjogo j ON a.CODJOGO = j.AppId 
  JOIN tbusuario u ON a.CODUSUARIO = u.IDUSU
  ORDER BY a.IDAVA DESC
";

$result = $conn->query($sql);
if (!$result) {
  die("Erro na consulta: " . $conn->error);
}

while ($row = $result->fetch_assoc()) {
  $avaliacoes[] = $row;
}

// DEBUG: Verificar se encontrou resenhas
echo "<!-- DEBUG: Total de resenhas encontradas: " . count($avaliacoes) . " -->";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GamesCore</title>
  <link rel="stylesheet" href="css/style_geral.css" />
  <link rel="stylesheet" href="css/style_gerenciar_resenhas.css" />
  <link rel="icon" href="imagens/controle_top.png" type="image/png">
</head>
<body>

<header>
  <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
    <img src="imagens/controle_ret.png" alt="Ícone de controle" class="logo-pequena" />
  </a>
  <h1>
    <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      <img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" />
    </a>
  </h1>

  <div class="header-opcoes">
    <?php if (!empty($idusu)): ?>
      <div class="usuario-logado" id="usuarioLogado">
        <div class="avatar-usuario"><?= $primeiraLetra ?></div>
        <span class="nome-usuario">
          <?php
            if ($tipo == 0):
              echo "Olá, " . htmlspecialchars($nickname);
            elseif ($tipo == 1):
              echo "Olá Admin, " . htmlspecialchars($nickname);
            elseif ($tipo == 2):
              echo "Olá Moderador, " . htmlspecialchars($nickname);
            endif;
          ?>
        </span>
        <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
          <?php if ($tipo == 1): ?>
            <button role="menuitem" onclick="cadastrarModera(<?= $idusu ?>)">Cadastrar Moderador</button>
            
          <?php elseif ($tipo == 2): ?>
            
          <?php endif; ?>
          <button role="menuitem" onclick="gerenciarResenhas(<?= $idusu ?>)">Gerenciar Resenhas</button>
          <button role="menuitem" onclick="editarPerfil(<?= $idusu ?>)">Editar Perfil</button>
          <button role="menuitem" onclick="window.location.href='php/logout.php'">Sair</button>
        </div>
      </div>
    <?php else: ?>
      <div class="usuario-logado">
        <button onclick="window.location.href='login.html'" class="botao-login">Fazer Login</button>
      </div>
    <?php endif; ?>
  </div>
</header>

<main>
    <button id="btnVoltar" role="menuitem" onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      ← Voltar
    </button>
  <h1>Resenhas de Jogos</h1>

  <!-- Container das resenhas -->
  <div id="lista-resenhas" class="container-resenhas">
    <?php if (!empty($avaliacoes)): ?>
      <?php foreach ($avaliacoes as $resenha): ?>
        <div class="resenha-card">
          <h2><?= htmlspecialchars($resenha['NOMEJOGO']) ?></h2>
          <small>Por: <?= htmlspecialchars($resenha['NICKNAME']) ?></small>

          <?php $nota = (int)$resenha['AVALIACAO']; ?>
          <div class="estrelas">
            <?php for ($i = 1; $i <= 5; $i++): ?>
              <?= $i <= $nota ? '<span class="estrela cheia">★</span>' : '<span class="estrela vazia">☆</span>' ?>
            <?php endfor; ?>
          </div>

          <p><?= nl2br(htmlspecialchars($resenha['RECOMENDACAO'])) ?></p>

          <div class="botoes-acao">
            <button class="btn-excluir" onclick="excluirResenhaGeral(<?= $resenha['IDAVA'] ?>, <?= (int)$idusu ?>)">Excluir</button>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p>Nenhuma resenha cadastrada no momento.</p>
    <?php endif; ?>
  </div>
</main>

<script>
function editarResenha(idAva, idusu) {
  window.location.href = 'editar_resenha.php?idAva=' + idAva + '&idusu=' + idusu;
}

function excluirResenhaGeral(idAva, idusu) {
  if (confirm("Tem certeza que deseja excluir esta resenha?")) {
    window.location.href = 'php/excluir_resenhageral.php?idAva=' + idAva + '&idusu=' + idusu;
  }
}
</script>

<script src="js/script.js"></script>
<script src="js/script_carrossel.js"></script>
</body>
</html>
