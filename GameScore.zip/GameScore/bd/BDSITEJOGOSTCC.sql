CREATE DATABASE bdsitejogostcc;

USE bdsitejogostcc;

CREATE TABLE tbusuario (
    IDUSU INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    EMAILUSUARIO VARCHAR(64) NOT NULL UNIQUE,
    SENHAUSUARIO VARCHAR(255) NOT NULL,
    TELEFONEUSUARIO VARCHAR(15) NOT NULL UNIQUE,
    NOMEUSUARIO VARCHAR(50) NOT NULL,
    NICKNAME VARCHAR(50) NOT NULL UNIQUE,
    TIPOUSUARIO INT NOT NULL,
    reset_token VARCHAR(255) NULL,
    reset_expira DATETIME NULL
) ENGINE=INNODB;

CREATE TABLE tbjogo (
    IDJOGO INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    AppId INT NOT NULL UNIQUE,
    NOMEJOGO VARCHAR(50) NOT NULL
) ENGINE=INNODB;


CREATE TABLE tbavaliacao (
    IDAVA INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    CODUSUARIO INT NOT NULL,
    CODJOGO INT NOT NULL,
    RECOMENDACAO VARCHAR(500) NOT NULL,
    AVALIACAO INT NOT NULL,
    FOREIGN KEY (CODUSUARIO) REFERENCES tbusuario(IDUSU),
    FOREIGN KEY (CODJOGO) REFERENCES tbjogo(AppId)
) ENGINE=INNODB;
/* Tipo de usuario:
	 2 - usuario moderador
	 1 - usuario administrador
	 0 - usuario comum
*/

INSERT INTO tbusuario (emailusuario, senhausuario, telefoneusuario, nomeusuario, nickname, tipousuario) 
VALUES 
('hugo122312231223@gmail.com','123','(17) 98825-3685','Hugo Martins Marques','hugom014',0),
('jose@gmail.com','123','(17) 99618-9560','José Pedro Quesada Muniz','kratos',1),
('joao@gmail.com','123','(17) 99272-5744','João Vitor Machado Marengoni','Jop',2);

INSERT INTO tbjogo (AppId, nomejogo) VALUES
(730,"Counter-Strike 2");

INSERT INTO tbavaliacao (CODUSUARIO, CODJOGO, RECOMENDACAO, AVALIACAO) VALUES
(1, 730, 'Jogo incrível, gráficos muito bem feitos e jogabilidade fluida.', 5),
(2, 730, 'Achei a campanha curta, mas a experiência foi boa.', 4),
(3, 730, 'Sistema online com alguns bugs, mas ainda é divertido.', 3),
(1, 730, 'Valeu cada hora jogada, recomendo muito.', 5),
(2, 730, 'Poderia ter mais modos de jogo, mas gostei bastante.', 4),
(3, 730, 'Som e ambientação excelentes, mas precisa otimização.', 3),
(1, 730, 'História cativante e personagens marcantes.', 5),
(2, 730, 'Achei o preço um pouco alto pelo conteúdo oferecido.', 3),
(3, 730, 'Bom para jogar com amigos, sozinho enjoa rápido.', 4),
(1, 730, 'Ótima rejogabilidade, sempre descubro algo novo.', 5);


