<?php
include "php/conexao.php";

$msg = null;
$user = null;

// Se recebeu o token pelo GET
if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $sql = "SELECT IDUSU, reset_expira FROM tbusuario WHERE reset_token = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $user = $res->fetch_assoc();

        // Verifica se ainda não expirou
        if (strtotime($user['reset_expira']) > time()) {
            // Se enviou nova senha
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nova_senha'])) {
                // Agora a senha vai ser salva em texto puro
                $senha = $_POST['nova_senha'];

                $sql = "UPDATE tbusuario 
                        SET SENHAUSUARIO = ?, reset_token = NULL, reset_expira = NULL 
                        WHERE IDUSU = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("si", $senha, $user['IDUSU']);

                if ($stmt->execute()) {
                    $msg = "Senha redefinida com sucesso! <a href='login.html'>Entrar</a>";
                } else {
                    $msg = "Erro ao redefinir senha!";
                }
            }
        } else {
            $msg = "Token expirado! Solicite um novo link.";
        }
    } else {
        $msg = "Token inválido!";
    }
} else {
    $msg = "Token não informado!";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Redefinir Senha - GameScore</title>
  <link rel="stylesheet" href="css/style_geral.css">
  <link rel="stylesheet" href="css/style_esqueci_senha.css">
</head>
<body>
  <header>
    <img src="imagens/controle_ret.png" alt="Ícone de controle de videogame" class="logo-pequena">
    <h1><img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita"></h1>
  </header>

  <main>
    <button id="btnVoltar" onclick="window.history.back()">← Voltar</button>
    <h1>Redefinir Senha</h1>

    <?php if ($msg) echo "<p>$msg</p>"; ?>

    <?php if ($user && strtotime($user['reset_expira']) > time() && (!$msg || strpos($msg, "sucesso") === false)): ?>
      <form method="POST">
        <label for="nova_senha">Nova senha:</label>
        <input type="password" name="nova_senha" id="nova_senha" required>
        <button type="submit">Salvar Nova Senha</button>
      </form>
    <?php endif; ?>
  </main>
</body>
</html>
