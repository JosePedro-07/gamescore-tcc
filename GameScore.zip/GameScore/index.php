<?php
/* 1 - incluir o arquivo de conexão */
include "php/conexao.php";

/* 2 - inicializar variáveis */
$idusu = null;
$nickname = null;
$tipo = null;
$primeiraLetra = null;

/* Helper para escapar HTML de forma consistente */
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* 3 - pegar id do usuário na URL */
if (isset($_GET["idusu"]) && is_numeric($_GET["idusu"])) {
    $idusu = intval($_GET["idusu"]);

    if ($idusu > 0) {
        if ($conn instanceof mysqli) {
            if ($stmt = $conn->prepare("SELECT NICKNAME, TIPOUSUARIO FROM tbusuario WHERE idusu=?")) {
                $stmt->bind_param("i", $idusu);
                if ($stmt->execute()) {
                    $res = $stmt->get_result();
                    if ($res && $res->num_rows > 0) {
                        $row = $res->fetch_assoc();
                        $nickname = $row["NICKNAME"] ?? null;
                        $tipo = isset($row["TIPOUSUARIO"]) ? (int)$row["TIPOUSUARIO"] : null;
                    }
                }
                $stmt->close();
            }
        }
    }
}

/* 4 - pegar a primeira letra do nickname */
if (!empty($nickname)) {
    if (function_exists('mb_substr')) {
        $primeiraLetra = strtoupper(mb_substr($nickname, 0, 1, 'UTF-8'));
    } else {
        $primeiraLetra = strtoupper(substr($nickname, 0, 1));
    }
}

/* 5 - Top 10 jogos com cache - ATUALIZADO COM FILTRO DE IMAGEM */
function steam_fetch_app_details($appId, $lang = 'portuguese') {
  $url = "https://store.steampowered.com/api/appdetails?appids=" . urlencode($appId) . "&l=" . urlencode($lang);
  $ch = curl_init($url);
  curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_CONNECTTIMEOUT => 8,
      CURLOPT_TIMEOUT => 12,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_USERAGENT => 'GameScoreBot/1.0 (+https://localhost)',
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_SSL_VERIFYHOST => 2,
  ]);
  $resp = curl_exec($ch);
  if ($resp === false) { curl_close($ch); return null; }
  $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
  curl_close($ch);
  if ($status < 200 || $status >= 300) return null;

  $json = json_decode($resp, true);
  if (!is_array($json) || !isset($json[$appId])) return null;

  $entry = $json[$appId];
  if (!isset($entry['success']) || !$entry['success'] || !isset($entry['data']) || !is_array($entry['data'])) return null;

  $data = $entry['data'];

  // ✅ FILTRO PARA APENAS JOGOS
  $type = strtolower($data['type'] ?? '');
  $categoriesToExclude = ['dlc', 'demo', 'mod', 'video', 'advertising', 'application', 'tool', 'hardware', 'series', 'episode', 'season'];
  
  if (in_array($type, $categoriesToExclude)) {
      return null;
  }

  $name = $data['name'] ?? null;
  
  // ✅ FILTRO MELHORADO PARA IMAGENS - Verifica múltiplos campos de imagem
  $image = $data['header_image'] ?? 
           $data['capsule_image'] ?? 
           $data['capsule_imagev5'] ?? 
           $data['background'] ?? 
           null;
  
  $link = "https://store.steampowered.com/app/" . ((int)$appId) . "/";

  // ✅ VALIDAÇÃO MAIS RÍGIDA DA IMAGEM
  if (!$name || !$image) return null;
  
  // Verifica se a imagem é uma URL válida e acessível
  if (!filter_var($image, FILTER_VALIDATE_URL)) return null;
  
  // Verifica se a imagem não é placeholder ou imagem padrão da Steam
  $badImages = [
      '/shared_images/',
      '/app/0/',
      'blank.jpg',
      'placeholder',
      'default'
  ];
  
  foreach ($badImages as $badImage) {
      if (stripos($image, $badImage) !== false) {
          return null;
      }
  }

  return [
      'id' => (int)$appId,
      'nome' => $name,
      'imagem' => $image,
      'link' => $link,
  ];
}

function get_top_games_from_steam(array $appIds, $cacheTtlSeconds = 1200) {
    $cacheDir = __DIR__ . DIRECTORY_SEPARATOR . 'cache';
    $cacheFile = $cacheDir . DIRECTORY_SEPARATOR . 'top10.json';
    if (!is_dir($cacheDir)) { @mkdir($cacheDir, 0777, true); }

    $now = time();
    if (is_file($cacheFile)) {
        $stat = @stat($cacheFile);
        $mtime = $stat ? ($stat['mtime'] ?? 0) : 0;
        if ($mtime && ($now - $mtime) < (int)$cacheTtlSeconds) {
            $cached = json_decode(@file_get_contents($cacheFile), true);
            if (is_array($cached)) return $cached;
        }
    }

    $result = [];
    foreach ($appIds as $aid) {
        $item = steam_fetch_app_details($aid, 'portuguese');
        if ($item) $result[] = $item;
        if (count($result) >= 10) break;
    }

    @file_put_contents($cacheFile, json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return $result;
}

// Lista de AppIds conhecidos de jogos populares (evita DLCs e aplicativos)
$defaultTopAppIds = [
    730,    // CS:GO
    578080, // PUBG
    570,    // Dota 2
    2694490, // Path of Exile 2
    1203220, // NARAKA: BLADEPOINT
    2767030, // Marvel Rivals
    271590, // GTA V
    1172470, // Apex Legends
    2923300, // Banana
    252490, // Rust    
];
$topJogos = get_top_games_from_steam($defaultTopAppIds);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GameScore</title>
  <link rel="stylesheet" href="css/style_geral.css"/>
  <link rel="stylesheet" href="css/style_index.css"/>
  <link rel="stylesheet" href="css/style_indexDeslogado.css"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="icon" href="imagens/controle_top.png" type="image/png">
</head>
<body>
<header>
  <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
    <img src="imagens/controle_ret.png" alt="Ícone de controle" class="logo-pequena" />
  </a>
  <h1>
    <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      <img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" />
    </a>
  </h1>
  <div class="header-opcoes">
    <div class="barra-pesquisa">
    <label for="barra-pesquisa" class="sr-only">Pesquisar jogos</label>
    <input type="text" id="barra-pesquisa" placeholder="Pesquisar jogos..." 
           oninput="pesquisarJogosDebounced(this.value)"
           onkeypress="if(event.key === 'Enter') pesquisarJogos(this.value)">
    <button type="button" class="btn-lupa" 
            onclick="pesquisarJogos(document.getElementById('barra-pesquisa').value)" 
            aria-label="Pesquisar">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#00f7ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
    </button>
</div>

    <?php if (!empty($idusu) && $idusu > 0): ?>
    <div class="usuario-logado" id="usuarioLogado">
      <div class="avatar-usuario"><?= e($primeiraLetra) ?></div>
      <span class="nome-usuario">
        <?php
        if ($tipo === 0) echo "Olá, " . e($nickname);
        elseif ($tipo === 1) echo "Olá Admin, " . e($nickname);
        elseif ($tipo === 2) echo "Olá Moderador, " . e($nickname);
        else echo e($nickname);
        ?>
      </span>
      <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
        <?php if ($tipo === 1): ?>
          <button role="menuitem" onclick="cadastrarModera(<?= (int)$idusu ?>)">Cadastrar Moderador</button>
          <button role="menuitem" onclick="gerenciarResenhasGerais(<?= (int)$idusu ?>)">Gerenciar Resenhas Gerais</button>
        <?php elseif ($tipo === 2): ?>
          <button role="menuitem" onclick="gerenciarResenhasGerais(<?= (int)$idusu ?>)">Gerenciar Resenhas Gerais</button>
        <?php endif; ?>
        <button role="menuitem" onclick="gerenciarResenhas(<?= (int)$idusu ?>)">Gerenciar Resenhas</button>
        <button role="menuitem" onclick="editarPerfil(<?= (int)$idusu ?>)">Editar Perfil</button>
        <button role="menuitem" onclick="window.location.href='php/logout.php'">Sair</button>
      </div>
    </div>
    <?php else: ?>
    <div class="usuario-logado">
      <button onclick="window.location.href='login.html'" class="botao-login">Fazer Login</button>
    </div>
    <?php endif; ?>
  </div>
</header>

<main>
  <section class="top-jogos">
    <h2>Top 10 Jogos Mais Jogados (2024)</h2>
    <?php if (!empty($topJogos)): ?>
      <div class="carrossel-container">
        <button class="prev" aria-label="Anterior">&#10094;</button>
        <div class="carrossel" id="top10">
          <?php foreach ($topJogos as $jogo): ?>
          <div class="card">
            <a href="detalhes.php?appId=<?= (int)$jogo['id'] ?>&idusu=<?= (int)$idusu ?>">
              <img src="<?= e($jogo['imagem']) ?>" alt="<?= e($jogo['nome']) ?>">
              <h3><?= e($jogo['nome']) ?></h3>
            </a>
          </div>
          <?php endforeach; ?>
        </div>
        <button class="next" aria-label="Próximo">&#10095;</button>
      </div>
    <?php else: ?>
      <p>Não foi possível carregar o Top 10 no momento. Tente novamente mais tarde.</p>
    <?php endif; ?>
  </section>

  
  <section class="todos-jogos">
    <h2>Todos os Jogos</h2>
    <div id="catalogo" class="catalogo-geral" aria-live="polite" aria-label="Catálogo de jogos"></div>
    <!-- BOTÃO LER MAIS/MOSTRAR MAIS -->
    <div class="container-botao-lermais">
    <div class="botoes-acao">
      <button id="btnLerMais" class="btn-lermais" onclick="carregarMaisJogos()">
          Mostrar Mais
      </button>
    </div>
    </div>
  </section>
</main>

<script>
  const idusuario = <?= (!empty($idusu) && $idusu > 0) ? (int)$idusu : 'null' ?>;
</script>
<script src="js/script.js"></script>
<script src="js/script_carrossel.js"></script>
</body>
</html>