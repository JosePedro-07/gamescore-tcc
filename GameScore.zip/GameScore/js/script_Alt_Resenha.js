$(document).ready(function(){

    $('#BotaoAlterarResenha').click(function(){
        if($('#Recomendacao').val()=='' || $('#Recomendacao').val()=="Recomendacao"){
            $('#mensagem').html("Recomendação inválida");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }else if($('#Avaliacao').val()=='' || $('#Avaliacao').val()=="Avaliação"){
            $('#mensagem').html("Avaliação inválida");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }else{
            re=$('#Recomendacao').val();
            av=$('#Avaliacao').val();
            //$('#mensagem').html("Usuário ok");
            //$('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        
        $.ajax({
            url:'php/atualizarResenha.php',
            type: 'POST',
            data: {idava:ia, recomendacao:re, avaliacao:av},

            success: function(response) {
                
                response=response.trim();
                
                if(response !== "erro"){
                $('#mensagem').html("Alteração feita com sucesso");
                $('#mensagem').fadeIn(300).delay(2000).fadeOut(200);

                var dados = response.split("|");
                var id = dados[0];
                
                //window.location.href = "index.php?idusu="+id;
                window.location.href = "gerenciar_resenhas.php?idusu="+idusu;
                
                }else{
                    $('#mensagem').html("Usuário não encontrado");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);

                }

            },

                error: function(xhr, status, error){
                    console.log("Erro na requisição:", error);

                }
            });

                
            }// fim do else
        
    });//fim do click no objeto id=botaoLoogar
});

$(document).ready(function(){

  function marcarEstrelas(valor) {
    $('#rating span').removeClass('selected');
    $('#rating span').each(function(){
      if ($(this).data('value') <= valor) {
        $(this).addClass('selected');
      }
    });
  }

  // Clique do usuário
  $('#rating span').on('click', function(){
      let valor = $(this).data('value');
      $('#Avaliacao').val(valor);
      marcarEstrelas(valor);
  });

  // Pré-seleciona com valor vindo do PHP
  let avaliacaoInicial = parseInt($('#Avaliacao').val());
  if(avaliacaoInicial > 0){
      marcarEstrelas(avaliacaoInicial);
  }

});


