const jogos = [
    { 
      id: 1, 
      titulo: "Minecraft", 
      imagem: "https://upload.wikimedia.org/wikipedia/pt/9/9c/Minecraft_capa.png", 
      categoria: "Aventura", 
      descricao: "Minecraft e um jogo de construcao e aventura em mundo aberto, onde os jogadores exploram um ambiente gerado aleatoriamente composto por blocos 3D. Nele, e possivel coletar recursos, construir estruturas, criar ferramentas, explorar cavernas, combater inimigos e sobreviver em diferentes modos de jogo, como o Sobrevivencia e o Criativo. O jogo destaca-se pela liberdade de criacao e pelo aspecto de exploracao, permitindo aos jogadores criar desde simples casas ate grandes cidades ou ate mesmo recriacoes de obras famosas. Lancado em 2011, o Minecraft se tornou um dos jogos mais populares de todos os tempos, com uma comunidade ativa e diversas atualizacoes ao longo dos anos." 
    },
    {
      id: 2,
      titulo: "Enigma Do Medo",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/7/7e/Arte_promocional_de_Enigma_do_Medo.jpg/330px-Arte_promocional_de_Enigma_do_Medo.jpg",
      categoria: "RPG, Ação, Aventura, Indie",
      descricao: "Explore mundos mágicos enquanto desvenda mistérios sombrios no universo de Ordem Paranormal! Em 'Enigma do Medo', você embarca em uma jornada imersiva ao lado de Mia Veríssimo e seu cão Lupi, enfrentando criaturas paranormais, resolvendo enigmas e investigando o desaparecimento de seu pai. Com uma mistura de pixel art e ambientes 3D, o jogo oferece uma experiência única de suspense e aventura."
    },
    {
      id: 3,
      titulo: "The Legend of Zelda: Breath of the Wild",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/0/0f/Legend_of_Zelda_Breath_of_the_Wild_capa.png",
      categoria: "Aventura, Ação, RPG",
      descricao: "Em 'The Legend of Zelda: Breath of the Wild', explore um vasto mundo aberto repleto de segredos, inimigos e santuários antigos. No papel de Link, o jogador deve despertar após um século de sono para derrotar a ameaça de Calamity Ganon e restaurar a paz em Hyrule. O jogo se destaca por sua liberdade de exploração, física avançada e estilo artístico encantador."
    },
    {
      id: 4,
      titulo: "Hollow Knight",
      imagem: "http://upload.wikimedia.org/wikipedia/en/thumb/0/04/Hollow_Knight_first_cover_art.webp/274px-Hollow_Knight_first_cover_art.webp.png",
      categoria: "Metroidvania, Ação, Indie",
      descricao: "Hollow Knight é um desafiador jogo de ação e exploração em 2D que se passa no mundo subterrâneo de Hallownest. Com visuais desenhados à mão e trilha sonora atmosférica, o jogador controla um cavaleiro silencioso em sua jornada por ruínas antigas, enfrentando criaturas misteriosas e descobrindo os segredos esquecidos do reino. Uma obra-prima do gênero metroidvania."
    },
    {
      id: 5,
      titulo: "DOOM Eternal",
      imagem: "https://upload.wikimedia.org/wikipedia/en/9/9d/Cover_Art_of_Doom_Eternal.png",
      categoria: "Tiro, Ação, FPS",
      descricao: "DOOM Eternal é um intenso jogo de tiro em primeira pessoa onde você assume o papel do Doom Slayer, enfrentando hordas de demônios em uma batalha épica pela sobrevivência da humanidade. Com combates rápidos, armas poderosas e trilha sonora agressiva, o jogo oferece uma experiência visceral e altamente dinâmica, ideal para fãs de ação frenética e desafios brutais."
    },
    {
      id: 6,
      titulo: "Red Dead Redemption 2",
      imagem: "https://upload.wikimedia.org/wikipedia/en/4/44/Red_Dead_Redemption_II.jpg",
      categoria: "Ação, Aventura, Mundo Aberto",
      descricao: "Red Dead Redemption 2 coloca o jogador no papel de Arthur Morgan, um fora da lei que vive no Velho Oeste. O jogo apresenta um vasto mundo aberto realista, cheio de missões, exploração, caçadas e momentos cinematográficos, sendo considerado um marco na narrativa interativa."
    },
    {
      id: 7,
      titulo: "God of War (2018)",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/8/82/God_of_War_2018_capa.png/330px-God_of_War_2018_capa.png",
      categoria: "Ação, Aventura",
      descricao: "God of War reinventa a franquia trazendo Kratos em uma jornada ao lado de seu filho Atreus pelos reinos da mitologia nórdica. Com combates intensos, narrativa emocionante e gráficos impressionantes, o jogo é uma experiência épica e profundamente humana."
    },
    {
      id: 8,
      titulo: "The Witcher 3: Wild Hunt",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/0/06/TW3_Wild_Hunt.png/330px-TW3_Wild_Hunt.png",
      categoria: "RPG, Aventura",
      descricao: "The Witcher 3 é um RPG de mundo aberto onde o jogador assume o papel de Geralt de Rívia, um bruxo caçador de monstros. Com escolhas impactantes, narrativas ramificadas e vasto conteúdo, é considerado um dos melhores jogos de todos os tempos."
    },
    {
      id: 9,
      titulo: "Celeste",
      imagem: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/68/Celeste_box_art_cropped.png/330px-Celeste_box_art_cropped.png",
      categoria: "Plataforma, Indie",
      descricao: "Celeste é um jogo indie de plataforma desafiador e emocional que acompanha Madeline em sua escalada até o topo da montanha Celeste, enfrentando obstáculos tanto físicos quanto internos. Reconhecido por sua jogabilidade precisa e narrativa tocante."
    },
    {
      id: 10,
      titulo: "GTA V",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/8/80/Grand_Theft_Auto_V_capa.png/250px-Grand_Theft_Auto_V_capa.png",
      categoria: "Ação, Aventura, Mundo Aberto",
      descricao: "Grand Theft Auto V é um dos jogos mais populares e vendidos da história, ambientado na fictícia cidade de Los Santos. O jogador acompanha três protagonistas em histórias interligadas, com liberdade total de exploração, missões variadas e um modo online massivo."
    },
    {
      id: 11,
      titulo: "Elden Ring",
      imagem: "https://upload.wikimedia.org/wikipedia/en/b/b9/Elden_Ring_Box_art.jpg",
      categoria: "RPG, Ação, Mundo Aberto",
      descricao: "Elden Ring combina o estilo desafiador da FromSoftware com um vasto mundo aberto, repleto de masmorras, chefes e segredos. Criado em colaboração com George R. R. Martin."
    },
    {
      id: 12,
      titulo: "Super Mario Odyssey",
      imagem: "https://upload.wikimedia.org/wikipedia/en/8/8d/Super_Mario_Odyssey.jpg",
      categoria: "Plataforma, Aventura",
      descricao: "Mario viaja por diversos reinos usando seu chapéu mágico Cappy para resgatar a Princesa Peach. Um jogo criativo e cheio de surpresas."
    },
    {
      id: 13,
      titulo: "Cyberpunk 2077",
      imagem: "https://upload.wikimedia.org/wikipedia/en/9/9f/Cyberpunk_2077_box_art.jpg",
      categoria: "RPG, Ação, Mundo Aberto",
      descricao: "Em Night City, você vive como V, um mercenário em busca de um implante único. Com narrativa ramificada e visual futurista."
    },
    {
      id: 14,
      titulo: "Sekiro: Shadows Die Twice",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/7/7b/Sekiro_Shadows_Die_Twice_capa.png/330px-Sekiro_Shadows_Die_Twice_capa.png",
      categoria: "Ação, Aventura",
      descricao: "Controle um shinobi em busca de vingança no Japão Sengoku. Conhecido por sua dificuldade e combates precisos."
    },
    {
      id: 15,
      titulo: "Resident Evil 4 Remake",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/3/30/Resident_Evil_4_%28remake%29.png/250px-Resident_Evil_4_%28remake%29.png",
      categoria: "Terror, Ação",
      descricao: "Leon S. Kennedy retorna para resgatar a filha do presidente em uma vila misteriosa. Remake com gráficos e jogabilidade modernizados."
    },
      {
      id: 16,
      titulo: "Hades",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/8/80/Hades_capa.jpg/330px-Hades_capa.jpg",
      categoria: "Roguelike, Ação, Indie",
      descricao: "Jogue como Zagreus, filho de Hades, tentando escapar do submundo. Combate rápido, narrativa envolvente e rejogabilidade alta."
    },
     {
      id: 17,
      titulo: "It Takes Two",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/d/dd/It_Takes_Two_capa.jpg/330px-It_Takes_Two_capa.jpg",
      categoria: "Cooperativo, Aventura, Puzzle",
      descricao: "It Takes Two é uma aventura cooperativa onde dois jogadores controlam um casal transformado em bonecos, enfrentando desafios criativos para salvar seu relacionamento. Com jogabilidade variada e narrativa divertida, o jogo é feito para ser jogado em dupla e destaca-se pela inovação e carisma."
    },
    {
      id: 18,
      titulo: "Little Nightmares",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/1/1b/Little_Nightmares_capa_do_jogo.jpg/260px-Little_Nightmares_capa_do_jogo.jpg",
      categoria: "Terror, Puzzle, Plataforma",
      descricao: "Little Nightmares é uma aventura sombria e surreal onde você controla Six, uma garotinha tentando escapar de um navio cheio de criaturas grotescas. Com atmosfera tensa, visual marcante e puzzles inteligentes, o jogo mistura medo e curiosidade em uma jornada memorável."
    },
    {
      id: 19,
      titulo: "Terraria",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/e/ee/Terraria_capa.png/250px-Terraria_capa.png",
      categoria: "Aventura, Sandbox, Indie",
      descricao: "Explore, construa e lute em um mundo 2D cheio de possibilidades. Mistura de ação e criatividade."
    },
    {
      id: 20,
      titulo: "Cuphead",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/c/c1/Cuphead_capa.png/330px-Cuphead_capa.png",
      categoria: "Plataforma, Ação, Indie",
      descricao: "Visual inspirado em desenhos dos anos 1930, com chefes desafiadores e jogabilidade precisa."
    },
    {
      id: 21,
      titulo: "Fall Guys",
      imagem: "https://upload.wikimedia.org/wikipedia/pt/thumb/9/96/Fall_Guys_capa.jpeg/330px-Fall_Guys_capa.jpeg",
      categoria: "Multiplayer, Party Game",
      descricao: "Compita em provas malucas com outros jogadores. Caótico, divertido e cheio de skins."
    }
    
  ];


  // Avaliações exemplos - colocar antes do uso
const avaliacoesExemplo = [
  { estrelas: 5, comentario: "Jogo incrível, viciante demais!" },
  { estrelas: 4, comentario: "Muito bom, só achei a dificuldade um pouco alta." },
  { estrelas: 3, comentario: "Legal, mas poderia ter mais conteúdo." },
  { estrelas: 5, comentario: "Gráficos e jogabilidade sensacionais!" },
  { estrelas: 2, comentario: "Não curti muito o estilo, mas é bom." },
];

// Avaliações para gerenciar resenhas
const avaliacoes = [
  { estrelas: 5, comentario: "Excelente jogo! Super recomendo." },
  { estrelas: 3, comentario: "Legal, mas tem alguns bugs chatos." },
  { estrelas: 1, comentario: "Muito ruim, não gostei da experiência." }
];

  // Tela Cadastro Modera
  function cadastraModera() {
    const nomeModera = document.getElementById('nomeCompletoModera').value.trim();
    const emailModera = document.getElementById('emailModera').value.trim();
    const telefoneModera = document.getElementById('telefoneModera').value.trim();
    const senhaModera = document.getElementById('senhaModera').value.trim();
    const confirmarModera = document.getElementById('confirmarSenhaModera').value.trim();

    if (!nomeModera || !emailModera || !telefoneModera || !senhaModera || !confirmarModera) {
      alert("Preencha todos os campos.");
      return;
    }

    if (senhaModera !== confirmarModera) {
      alert("As senhas não coincidem.");
      return;
    }

    alert(`Usuário ${nomeModera} cadastrado com sucesso!`);
    window.location.href = "index.php";
  }

   function pesquisarJogos(termo) {
    const cards = document.querySelectorAll('.card h3');
    cards.forEach(card => {
      const jogo = card.textContent.toLowerCase();
      card.closest('.card').style.display = jogo.includes(termo.toLowerCase()) ? 'block' : 'none';
    });
  }

  function salvarAvaliacao() {
    const texto = document.getElementById("comentario")?.value || "";
    const estrelas = document.querySelectorAll(".estrelas span.selecionada").length;

    if (estrelas === 0) {
      alert("Por favor, selecione ao menos uma estrela.");
      return;
    }

    alert(`Avaliação salva com ${estrelas} estrela(s) e comentário: "${texto}"`);
  }




  



  

  /*function exibirResenhas() {
    const container = document.getElementById('lista-resenhas');
    if (!container) return;

    container.innerHTML = '';

    avaliacoes.forEach((avaliacao, index) => {
      const div = document.createElement('div');
      div.className = 'resenha';

      div.innerHTML = `
        <div class="resenha-header">
          <span class="estrelas">${gerarEstrelas(avaliacao.estrelas)}</span>
          <div>
            <button class="btn-excluir" onclick="excluirResenha(${index})">Excluir</button>
            <button class="btn-excluir" onclick="editarResenha(${index})">Editar</button>
          </div>
        </div>
        <p class="comentario" id="comentario-${index}">${avaliacao.comentario}</p>
        <textarea id="textarea-${index}" style="display:none; width:100%; margin-top:10px; background-color:#002a44; color:#cceeff; border-radius:8px; border:1px solid #0077aa; padding:0.5rem;"></textarea>
        <button id="salvar-${index}" style="display:none; margin-top:8px;" class="btn-excluir" onclick="salvarEdicao(${index})">Salvar</button>
      `;

      container.appendChild(div);
    });
  }*/

  

  function excluirResenha(index) {
    if (confirm("Tem certeza que deseja excluir esta resenha?")) {
      avaliacoes.splice(index, 1);
      exibirResenhas();
    }
  }