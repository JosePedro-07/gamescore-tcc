 // === Carrossel com autoplay ===
  const carrosselContainer = document.querySelector('.carrossel-container');
  const carrossel = document.querySelector('.carrossel');
  const prevBtn = document.querySelector('.prev');
  const nextBtn = document.querySelector('.next');

  if (carrossel && prevBtn && nextBtn && carrosselContainer) {
    let index = 0;
    const cardWidth = 220;
    const totalCards = carrossel.children.length;
    const visibleCards = Math.floor(carrosselContainer.offsetWidth / cardWidth);
    const maxIndex = totalCards - visibleCards;

    nextBtn.addEventListener('click', () => {
      index++;
      if (index > maxIndex) index = 0;
      carrossel.style.transform = `translateX(-${index * cardWidth}px)`;
    });

    prevBtn.addEventListener('click', () => {
      index--;
      if (index < 0) index = maxIndex;
      carrossel.style.transform = `translateX(-${index * cardWidth}px)`;
    });

    let autoplay = setInterval(() => {
      nextBtn.click();
    }, 3000);

    carrosselContainer.addEventListener('mouseenter', () => {
      clearInterval(autoplay);
    });

    carrosselContainer.addEventListener('mouseleave', () => {
      autoplay = setInterval(() => {
        nextBtn.click();
      }, 3000);
    });
  }





  // Dropdown do usuário
  const usuarioLogado = document.getElementById("usuarioLogado");
  const menuUsuario = document.getElementById("menuUsuario");
  if (usuarioLogado && menuUsuario) {
    usuarioLogado.addEventListener("click", (e) => {
      e.stopPropagation();
      const isHidden = menuUsuario.getAttribute("aria-hidden") === "true";
      menuUsuario.setAttribute("aria-hidden", String(!isHidden));
    });

    //para o carrossel nn fechar o dropdown
    document.addEventListener("click", (e) => {
      const isClickInsideMenu = menuUsuario.contains(e.target);
      const isClickOnAvatar = usuarioLogado.contains(e.target);
      const isClickOnCarrossel = carrosselContainer && carrosselContainer.contains(e.target);
    
      if (!isClickInsideMenu && !isClickOnAvatar && !isClickOnCarrossel) {
        menuUsuario.setAttribute("aria-hidden", "true");
      }
    });
    

  }