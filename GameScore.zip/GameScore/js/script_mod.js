$(document).ready(function(){

    $('#BotaoCadastraMod').click(function(){

        if($('#nomemod').val().trim() === '' || $('#nomemod').val().trim() === "Nome Completo") {
            $('#mensagem').html("Nome Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#nickmod').val().trim() === '' || $('#nickmod').val().trim() === "Nick Usuário") {
            $('#mensagem').html("Nick Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#emailmod').val().trim() === '' || $('#emailmod').val().trim() === "Email Usuário") {
            $('#mensagem').html("Email Inválido").fadeIn(300).delay(2000).fadeOut(400);//MONTAR VERIFICAÇÃO SE TEM @
        }
        else if($('#telmod').val().trim() === '' || $('#telmod').val().trim() === "Telefone Usuário") {
            $('#mensagem').html("Telefone Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#senhamod').val().trim() === '' || $('#senhamod').val().trim() === "Senha") {
            $('#mensagem').html("Senha Inválida").fadeIn(300).delay(2000).fadeOut(400);
        }
        else{
        no=$('#nomemod').val();
        ni=$('#nickmod').val();
        em=$('#emailmod').val();
        te=$('#telmod').val();
        se=$('#senhamod').val();        
        

        //$('#mensagem').html("Dados ok para cadastro");
        //$('#mensagem').fadeIn(300).delay(2000).fadeOut(400);

        $.ajax({
            url:'php/cadModera.php',
            type: 'POST',
            data: {nomemod:no, nickmod:ni, emailmod:em, telmod:te, senhamod:se},

            success: function(response) {
                
                response=response.trim();
                
                if(response !== "erro"){
                    $('#mensagem').html("Cadastrado com sucesso");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
                    

                }else{
                    $('#mensagem').html("Erro no Cadastro");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
                }
            },
                error: function(xhr, status, error){
                    console.log("Erro na requisição: ", error);
                }
        });
    }//fim do else

});//fim do clique no botao Cadastrar


});//fim


function toggleSenha(idCampo, botao) {
    const campo = document.getElementById(idCampo);
    const img = botao.querySelector(".icone-olho");
  
    if (campo.type === "password") {
      campo.type = "text";
      img.src = "imagens/esconder.png";
      img.alt = "Esconder senha";
    } else {
      campo.type = "password";
      img.src = "imagens/mostrar.png";
      img.alt = "Mostrar senha";
    }
}