// Função utilitária para pegar parâmetros da URL
function getParametroUrl(nome) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(nome);
}

$(document).ready(function(){
    
    let ai = getParametroUrl("appId");
    let iu = getParametroUrl("idusu");

    $('#BotaoSalvarAvaliacao').click(function(){

        if($('#comentario').val().trim() === '' || $('#comentario').val().trim() === "Digite sua opinião...") {
            $('#mensagem').html("Comentário Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else{
            let co = $('#comentario').val();
            let av = $('#Avaliacao').val();

            // ✅ ADICIONADO: Verificar se avaliação foi selecionada
            if(av === "0" || av === "") {
                $('#mensagem').html("Selecione uma avaliação com as estrelas").fadeIn(300).delay(2000).fadeOut(400);
                return;
            }

            $.ajax({
                url:'php/cadAva.php',
                type: 'POST',
                data: {
                    appId: ai,
                    idusu: iu,
                    recomendacao: co,
                    avaliacao: av
                },
                success: function(response) {
                    response = response.trim();
                    
                    if(response !== "erro"){
                        $('#mensagem').html("Avaliação cadastrada com sucesso").fadeIn(300).delay(2000).fadeOut(400);
                        setTimeout(function(){
                            $('#avaliacaoForm')[0].reset();
                            $('#Avaliacao').val("0");
                            pintarEstrelas(0);
                            setTimeout(function(){
                                location.reload();
                            }, 1000);
                        }, 2500);
                    } else {
                        $('#mensagem').html("Erro no Cadastro").fadeIn(300).delay(2000).fadeOut(400);
                    }
                },
                error: function(xhr, status, error){
                    console.log("Erro na requisição: ", error);
                    $('#mensagem').html("Erro na requisição").fadeIn(300).delay(2000).fadeOut(400);
                }
            });
        }

    });

});

// ✅ ADICIONADO: Função para pintar estrelas
function pintarEstrelas(valor) {
    const stars = document.querySelectorAll('#rating span');
    if(stars.length > 0) {
        stars.forEach((star, index) => {
            if (index < valor) {
                star.textContent = '★';
                star.style.color = '#ffcc00';
            } else {
                star.textContent = '☆';
                star.style.color = '#ccc';
            }
        });
    }
}