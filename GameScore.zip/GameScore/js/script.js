document.addEventListener("DOMContentLoaded", () => {

  function carregarAvaliacoes() {
    const container = document.getElementById("avaliacoes-usuarios");
    if (!container) return;

    container.querySelectorAll(".avaliacao-usuario").forEach(el => el.remove());

    avaliacoesExemplo.forEach(av => {
      const div = document.createElement("div");
      div.className = "avaliacao-usuario";

      const estrelasHtml = "★".repeat(av.estrelas) + "☆".repeat(5 - av.estrelas);

      div.innerHTML = `
        <div class="estrelas">${estrelasHtml}</div>
        <p>"${av.comentario}"</p>
      `;

      container.appendChild(div);
    });
  }

  // Função única para carregar detalhes do jogo
  function carregarDetalhes() {
    const jogo = JSON.parse(localStorage.getItem("jogoSelecionado"));
    const container = document.getElementById("detalhes");
    const imgJogo = document.getElementById("imagem-jogo");
    if (!jogo || !container || !imgJogo) return;

    imgJogo.src = jogo.imagem;
    imgJogo.alt = `Imagem do jogo ${jogo.titulo}`;

    container.innerHTML = `
      <h2>${jogo.titulo}</h2>
      <p>${jogo.descricao}</p>
    `;

    carregarAvaliacoes();
  }

  // Funções para menu de usuário
  window.cadastrarModera = function(idusuario){
    window.location.href = "cadastro_modera.php?idusu=" + idusuario;
    const menuUsuario = document.getElementById("menuUsuario");
    if (menuUsuario) menuUsuario.setAttribute("aria-hidden", "true");
  }
  
  window.cadastrarJogo = function(idusuario){
    window.location.href = "cadastro_jogo.php?idusu=" + idusuario;
    const menuUsuario = document.getElementById("menuUsuario");
    if (menuUsuario) menuUsuario.setAttribute("aria-hidden", "true");
  }
  
  window.gerenciarResenhas = function(idusuario) {
    window.location.href = "gerenciar_resenhas.php?idusu=" + idusuario;
    const menuUsuario = document.getElementById("menuUsuario");
    if (menuUsuario) menuUsuario.setAttribute("aria-hidden", "true");
  }
  
  window.gerenciarResenhasGerais = function(idusuario) {
    window.location.href = "gerenciar_resenhas_gerais.php?idusu=" + idusuario;
    const menuUsuario = document.getElementById("menuUsuario");
    if (menuUsuario) menuUsuario.setAttribute("aria-hidden", "true");
  }
  
  window.editarPerfil = function(idusuario) {
    window.location.href = "editar_perfil.php?idusu=" + idusuario;
    const menuUsuario = document.getElementById("menuUsuario");
    if (menuUsuario) menuUsuario.setAttribute("aria-hidden", "true");
  }

  window.sair = function() {
    fetch('logout.php', { method: 'GET' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const url = new URL(window.location.href);
                url.search = '';
                window.history.replaceState({}, document.title, url);
                location.reload();
            }
        });
  }

  // ========== NOVAS FUNÇÕES PARA BOTÃO "LER MAIS" ==========
  
  // Variáveis para controle de paginação
  window.paginaJogos = 1;
  window.jogosPorPagina = 12;
  window.carregando = false;
  window.todosJogosCarregados = [];

  // Chamadas iniciais
  if (document.getElementById("detalhes")) carregarDetalhes();
  if (document.getElementById("top10")) carregarTop10();
  
  // Inicializar carregamento de jogos
  if (document.getElementById("catalogo")) {
    carregarTodosJogos();
  }

}); // fecha o DOMContentLoaded

// ========== SISTEMA DE BOTÃO "LER MAIS" ==========

// Função para carregar mais jogos
window.carregarMaisJogos = async function() {
    if (window.carregando) return;
    
    window.carregando = true;
    const btnLerMais = document.getElementById('btnLerMais');
    const catalogo = document.getElementById('catalogo');
    
    if (!btnLerMais || !catalogo) {
        console.error('Elementos não encontrados');
        window.carregando = false;
        return;
    }

    // Mostrar loading
    btnLerMais.disabled = true;
    btnLerMais.textContent = ' Carregando...';
    
    try {
        // Simular delay de carregamento
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Carregar próximos jogos
        const inicio = (window.paginaJogos - 1) * window.jogosPorPagina;
        const fim = inicio + window.jogosPorPagina;
        const jogosParaMostrar = window.todosJogosCarregados.slice(inicio, fim);
        
        if (jogosParaMostrar.length > 0) {
            // Adicionar novos jogos ao catálogo
            jogosParaMostrar.forEach(jogo => {
                const card = criarCardJogo(jogo);
                catalogo.appendChild(card);
            });
            
            window.paginaJogos++;
            
            // Verificar se há mais jogos para carregar
            const totalExibido = window.paginaJogos * window.jogosPorPagina;
            if (totalExibido >= window.todosJogosCarregados.length) {
                btnLerMais.style.display = 'none';
                mostrarMensagemFim();
            } else {
                btnLerMais.disabled = false;
                btnLerMais.textContent = 'Mostrar Mais';
            }
        } else {
            // Não há mais jogos
            btnLerMais.style.display = 'none';
            mostrarMensagemFim();
        }
        
    } catch (error) {
        console.error('Erro ao carregar mais jogos:', error);
        btnLerMais.textContent = '❌ Erro ao carregar';
        setTimeout(() => {
            btnLerMais.textContent = '📚 Tentar Novamente';
            btnLerMais.disabled = false;
        }, 2000);
    } finally {
        window.carregando = false;
    }
}

// Função para criar card do jogo
function criarCardJogo(jogo) {
    const card = document.createElement('div');
    card.className = 'card';
    
    // Extrair informações do jogo
    const nome = jogo.name || jogo.nome || jogo.NOMEJOGO || jogo.titulo || 'Jogo';
    const appid = jogo.appid || jogo.AppId || jogo.id;
    const imagem = jogo.imagem || 
                  (appid ? `https://cdn.cloudflare.steamstatic.com/steam/apps/${appid}/header.jpg` : 'imagens/placeholder.png');
    
    const link = appid ? 
        `detalhes.php?appId=${appid}&idusu=${idusuario}` : 
        `detalhes.php?jogoId=${jogo.IDJOGO || jogo.id}&idusu=${idusuario}`;
    
    card.innerHTML = `
        <a href="${link}">
            <div class="card-jogo">
                <img src="${imagem}" alt="${nome}" onerror="this.src='imagens/placeholder.png'">
                <h3>${nome}</h3>
            </div>
        </a>
    `;
    
    return card;
}

// Função para mostrar mensagem de fim
function mostrarMensagemFim() {
    const container = document.querySelector('.container-botao-lermais');
    if (container) {
        container.innerHTML = '<p style="text-align: center; color: #aaa; font-style: italic; margin: 20px 0;">Todos os jogos foram carregados!</p>';
    }
}

// ========== FUNÇÕES EXISTENTES ATUALIZADAS ==========

// Corrigido para JS (antes estava em PHP)
async function getAppList() {
  try {
    const resposta = await fetch("https://api.steampowered.com/ISteamApps/GetAppList/v2/");
    const dados = await resposta.json();
    return dados.applist?.apps || [];
  } catch (erro) {
    console.error("Erro ao buscar lista de apps:", erro);
    return [];
  }
}

// Top 10 (corrigido para mandar o appid correto)
function carregarTop10() {
  const container = document.getElementById("top10");
  if (!container || typeof jogos === "undefined") return;

  const topJogos = jogos.slice(0, 10);
  container.innerHTML = "";

  topJogos.forEach(jogo => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <img src="${jogo.imagem}" alt="Imagem do jogo ${jogo.titulo}" />
      <h3>${jogo.titulo}</h3>
    `;
    div.onclick = () => {
      localStorage.setItem("jogoSelecionado", JSON.stringify(jogo));
      window.location.href = "detalhes.php?appid=" + jogo.appid;
    };

    container.appendChild(div);
  });
}

function inicializarEstrelas() {
  const container = document.getElementById("estrelas");
  if (!container) return;

  container.innerHTML = ''; // limpa antes
  for (let i = 1; i <= 5; i++) {
    const span = document.createElement("span");
    span.textContent = '☆';
    span.dataset.valor = i;
    span.style.cursor = 'pointer';
    span.style.fontSize = '2rem';
    span.style.color = '#ffcc00';
    span.addEventListener('mouseenter', () => {
      pintarEstrelas(i);
    });
    span.addEventListener('mouseleave', () => {
      pintarEstrelas(container.dataset.selecionado || 0);
    });
    span.addEventListener('click', () => {
      container.dataset.selecionado = i;
      pintarEstrelas(i);
    });
    container.appendChild(span);
  }

  function pintarEstrelas(valor) {
    Array.from(container.children).forEach(span => {
      span.textContent = (parseInt(span.dataset.valor) <= valor) ? '★' : '☆';
    });
  }
}

// chama a função quando a página carregar
if (document.getElementById("estrelas")) {
  inicializarEstrelas();
}

// Função atualizada para carregar todos os jogos
async function carregarTodosJogos() {
  const container = document.getElementById("catalogo");
  if (!container) return;

  try {
    const resposta = await fetch("php/listar_jogos_api.php");
    const jogos = await resposta.json();

    console.log("DEBUG - Dados recebidos:", jogos);

    window.todosJogosCarregados = jogos || [];
    container.innerHTML = ''; // limpa antes

    // Carregar primeira página de jogos
    const jogosIniciais = window.todosJogosCarregados.slice(0, window.jogosPorPagina);
    
    jogosIniciais.forEach(jogo => {
      const card = criarCardJogo(jogo);
      container.appendChild(card);
    });

    // Configurar botão "Ler Mais" se houver mais jogos
    if (window.todosJogosCarregados.length > window.jogosPorPagina) {
      window.paginaJogos = 2; // Já carregamos a primeira página
      const btnLerMais = document.getElementById('btnLerMais');
      if (btnLerMais) {
        btnLerMais.style.display = 'block';
        btnLerMais.disabled = false;
      }
    } else {
      // Esconder botão se não há mais jogos
      const btnLerMais = document.getElementById('btnLerMais');
      if (btnLerMais) {
        btnLerMais.style.display = 'none';
      }
      mostrarMensagemFim();
    }

  } catch (erro) {
    console.error("Erro ao carregar jogos:", erro);
    container.innerHTML = "<p>Não foi possível carregar os jogos no momento.</p>";
    
    // Esconder botão em caso de erro
    const btnLerMais = document.getElementById('btnLerMais');
    if (btnLerMais) {
      btnLerMais.style.display = 'none';
    }
  }
}

// Funções antigas de paginação (mantidas para compatibilidade)
let todosJogos = [];
let jogosPorPaginaAntigo = 20;
let paginaAtual = 0;

function renderizarJogos() {
  const container = document.getElementById("catalogo");
  if (!container) return;

  const inicio = paginaAtual * jogosPorPaginaAntigo;
  const fim = inicio + jogosPorPaginaAntigo;
  const jogosParaMostrar = todosJogos.slice(inicio, fim);

  jogosParaMostrar.forEach(jogo => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <a href="detalhes.php?appId=${jogo.appid}&idusu=${idusuario}">
        <div class="card-jogo">
          <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/${jogo.appid}/header.jpg" alt="${jogo.name}" onerror="this.src='imagens/placeholder.png'">
          <h3>${jogo.name}</h3>
        </div>
      </a>
    `;
    container.appendChild(card);
  });

  paginaAtual++;

  if (paginaAtual * jogosPorPaginaAntigo >= todosJogos.length) {
    document.getElementById("btnMostrarMais").style.display = "none";
  }
}

// ========== FUNÇÃO DE PESQUISA ==========
function pesquisarJogos(termo) {
  const catalogo = document.getElementById('catalogo');
  const btnLerMais = document.getElementById('btnLerMais');
  
  if (!catalogo) return;
  
  if (termo.length === 0) {
    // Se a pesquisa estiver vazia, mostrar todos os jogos novamente
    catalogo.innerHTML = '';
    carregarTodosJogos();
    if (btnLerMais) btnLerMais.style.display = 'block';
    return;
  }
  
  // Filtrar jogos localmente
  const jogosFiltrados = window.todosJogosCarregados.filter(jogo => {
    const nome = jogo.name || jogo.nome || jogo.NOMEJOGO || jogo.titulo || '';
    return nome.toLowerCase().includes(termo.toLowerCase());
  });
  
  // Atualizar catálogo com resultados filtrados
  catalogo.innerHTML = '';
  
  if (jogosFiltrados.length > 0) {
    jogosFiltrados.forEach(jogo => {
      const card = criarCardJogo(jogo);
      catalogo.appendChild(card);
    });
    
    // Esconder botão "Ler Mais" durante pesquisa
    if (btnLerMais) btnLerMais.style.display = 'none';
  } else {
    catalogo.innerHTML = '<p style="text-align: center; color: #aaa;">Nenhum jogo encontrado para "' + termo + '"</p>';
    if (btnLerMais) btnLerMais.style.display = 'none';
  }
}

// Gerenciar resenhas
function gerarEstrelas(qtd) {
  let estrelas = '';
  for (let i = 0; i < 5; i++) {
    estrelas += i < qtd ? '★' : '☆';
  }
  return estrelas;
}

function editarResenha(index) { 
  const comentarioEl = document.getElementById(`comentario-${index}`);
  const textareaEl = document.getElementById(`textarea-${index}`);
  const salvarBtn = document.getElementById(`salvar-${index}`);

  textareaEl.value = avaliacoes[index].comentario;
  comentarioEl.style.display = 'none';
  textareaEl.style.display = 'block';
  salvarBtn.style.display = 'inline-block';
}

function salvarEdicao(index) {
  const textareaEl = document.getElementById(`textarea-${index}`);
  const comentarioEl = document.getElementById(`comentario-${index}`);

  avaliacoes[index].comentario = textareaEl.value;
  comentarioEl.textContent = textareaEl.value;
  comentarioEl.style.display = 'block';
  textareaEl.style.display = 'none';
  document.getElementById(`salvar-${index}`).style.display = 'none';
}




// Função para pesquisar jogos
async function pesquisarJogos(termo) {
    if (!termo || termo.trim() === '') {
        // Se termo vazio, recarrega todos os jogos
        carregarCatalogo();
        return;
    }

    try {
        const response = await fetch(`php/pesquisar_jogos.php?termo=${encodeURIComponent(termo)}&idusu=${idusuario || ''}`);
        const data = await response.json();

        const catalogo = document.getElementById('catalogo');
        const btnLerMais = document.getElementById('btnLerMais');

        if (data.success) {
            // Esconde o botão "Mostrar Mais" durante a pesquisa
            if (btnLerMais) {
                btnLerMais.style.display = 'none';
            }

            if (data.jogos.length > 0) {
                catalogo.innerHTML = data.jogos.map(jogo => `
                    <div class="card">
                        <a href="${jogo.link}">
                            <img src="${jogo.imagem || 'imagens/placeholder.jpg'}" alt="${jogo.nome}" onerror="this.src='imagens/placeholder.jpg'">
                            <h3>${jogo.nome}</h3>
                            ${jogo.genero ? `<p class="genero">${jogo.genero}</p>` : ''}
                        </a>
                    </div>
                `).join('');
            } else {
                catalogo.innerHTML = `<p class="sem-resultados">Nenhum jogo encontrado para "${data.termo}"</p>`;
            }
        } else {
            catalogo.innerHTML = `<p class="erro-pesquisa">Erro na pesquisa: ${data.message}</p>`;
        }
    } catch (error) {
        console.error('Erro na pesquisa:', error);
        document.getElementById('catalogo').innerHTML = `<p class="erro-pesquisa">Erro ao realizar pesquisa</p>`;
    }
}

// Função para recarregar o catálogo completo
function carregarCatalogo() {
    // Reseta para o estado inicial (carrega primeiros jogos)
    const btnLerMais = document.getElementById('btnLerMais');
    if (btnLerMais) {
        btnLerMais.style.display = 'block';
    }
    
    // Aqui você pode chamar a função que carrega os jogos iniciais
    // Se não tiver, pode recarregar a página ou fazer outra requisição
    location.reload(); // Opção simples - recarrega a página
}

// Adiciona evento de input com debounce para pesquisa em tempo real
let timeoutPesquisa;
function pesquisarJogosDebounced(termo) {
    clearTimeout(timeoutPesquisa);
    timeoutPesquisa = setTimeout(() => {
        pesquisarJogos(termo);
    }, 500); // Espera 500ms após o usuário parar de digitar
}

// Atualize o HTML para usar a versão com debounce:
// <input type="text" id="barra-pesquisa" placeholder="Pesquisar jogos..." oninput="pesquisarJogosDebounced(this.value)">