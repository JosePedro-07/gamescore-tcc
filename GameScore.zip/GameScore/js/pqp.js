$(document).ready(function(){

    // Captura o ID da URL
    const params = new URLSearchParams(window.location.search);
    const id = params.get('idusu'); // CORREÇÃO: mudou de 'id' para 'idusu'

    console.log("ID encontrado na URL: " + id);

    // Funções para limpar placeholders ao clicar
    $('#nomeEdt').click(function(){
        if($(this).val()=="Nome"){
            $(this).val('');
        }
    });

    $('#nickEdt').click(function(){
        if($(this).val()=="Nick"){
            $(this).val('');
        }
    });

    $('#emailEdt').click(function(){
        if($(this).val()=="Email"){
            $(this).val('');
        }
    });

    $('#telefoneEdt').click(function(){
        if($(this).val()=="Telefone"){
            $(this).val('');
        }
    });

    $('#senhaAtual').click(function(){
        if($(this).val()=="Senha Atual"){
            $(this).val('');
        }
    });

    $('#senhaNova').click(function(){
        if($(this).val()=="Senha Nova"){
            $(this).val('');
        }
    });

    $('#BotaoSalvarAlt').click(function(){
        // Validações
        if($('#nomeEdt').val()=='' || $('#nomeEdt').val()=="Nome"){
            $('#mensagem').html("Nome inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }
        
        if($('#nickEdt').val()=='' || $('#nickEdt').val()=="Nick"){
            $('#mensagem').html("NickName inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }
        
        if($('#emailEdt').val()=='' || $('#emailEdt').val()=="Email"){
            $('#mensagem').html("Email inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }
        
        if($('#telefoneEdt').val()=='' || $('#telefoneEdt').val()=="Telefone"){
            $('#mensagem').html("telefone inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }
        
        if($('#senhaAtual').val()=='' || $('#senhaAtual').val()=="Senha Atual"){
            $('#mensagem').html("Senha atual inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }

        if($('#senhaNova').val()=='' || $('#senhaAtual').val()=="Senha Atual"){
            $('#mensagem').html("Senha atual inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }

        if($('#ConfirmaSenhaNova').val()=='' || $('#ConfirmaSenhaNova').val()=="Confirmar Senha Nova"){
            $('#mensagem').html("Confirmar Senha Nova inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }


        ConfirmaSenhaNova
        // Se senha nova estiver vazia, usar a senha atual
        let senhaNova = $('#senhaNova').val();
        if(senhaNova == '' || senhaNova == "Senha Nova"){
            senhaNova = $('#senhaAtual').val();
        }

        // Preparar dados
        const dados = {
            id: id,
            nome: $('#nomeEdt').val(),
            nick: $('#nickEdt').val(),
            email: $('#emailEdt').val(),
            telefone: $('#telefoneEdt').val(),
            senhaat: $('#senhaAtual').val(),
            senhanova: senhaNova
        };

        console.log("Dados enviados:", dados);

        // Primeiro verifica a senha atual
        $.ajax({
            url: 'php/verificaSenha.php',
            type: 'POST',
            data: { id: id, senhaat: dados.senhaat },

            success: function(response) {
                response = response.trim();
                console.log("Resposta verificaSenha:", response);

                if(response === "senha_correta") {
                    // Se senha está correta, atualiza os dados
                    atualizarPerfil(dados);
                } else {
                    mostrarMensagem("Senha atual incorreta", "erro");
                }
            },

            error: function(xhr, status, error) {
                console.log("Erro na verificação de senha:", error);
                mostrarMensagem("Erro ao verificar senha", "erro");
            }
        });

    });//fim do click no botão salvar

    // Função para atualizar o perfil
    function atualizarPerfil(dados) {
        console.log("Atualizando perfil com dados:", dados);
        
        $.ajax({
            url: 'php/atualizaUsuario.php',
            type: 'POST',
            data: dados,

            success: function(response) {
                response = response.trim();
                console.log("Resposta atualizaUsuario:", response);

                if(response === "sucesso") {
                    mostrarMensagem("Dados atualizados com sucesso!", "sucesso");
                    
                    // Redirecionar após 2 segundos
                    setTimeout(function(){
                        window.location.href = "editar_perfil.php?idusu=" + id;
                    }, 15000);
                    
                } else if(response === "senha_incorreta") {
                    mostrarMensagem("Senha atual incorreta", "erro");
                } else {
                    mostrarMensagem("Erro ao atualizar dados: " + response, "erro");
                }
            },

            error: function(xhr, status, error) {
                console.log("Erro na atualização:", error);
                mostrarMensagem("Erro ao atualizar perfil", "erro");
            }
        });
    }

    // Função para mostrar mensagens
    function mostrarMensagem(mensagem, tipo) {
        const mensagemDiv = $('#mensagem');
        mensagemDiv.text(mensagem);
        
        if(tipo === "sucesso") {
            mensagemDiv.css({
                'color': '#00ff00',
                'background-color': 'rgba(0, 255, 0, 0.1)',
                'padding': '10px',
                'border-radius': '5px'
            });
        } else {
            mensagemDiv.css({
                'color': '#ff4444',
                'background-color': 'rgba(255, 0, 0, 0.1)',
                'padding': '10px',
                'border-radius': '5px'
            });
        }
        
        mensagemDiv.fadeIn(300).delay(3000).fadeOut(400);
    }

});//fim do document ready

// Função para mostrar/esconder senha
function toggleSenha(idCampo, botao) {
    const campo = document.getElementById(idCampo);
    const img = botao.querySelector(".icone-olho");
  
    if (campo.type === "password") {
        campo.type = "text";
        img.src = "imagens/esconder.png";
        img.alt = "Esconder senha";
    } else {
        campo.type = "password";
        img.src = "imagens/mostrar.png";
        img.alt = "Mostrar senha";
    }
}