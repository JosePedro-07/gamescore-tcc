document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("formCadastroJogo");
    const capaInput = document.getElementById("capa");
    const preview = document.getElementById("previewCapa");
  
    // Pré-visualização da capa
    capaInput.addEventListener("change", () => {
      const file = capaInput.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = e => {
          preview.innerHTML = `<img src="${e.target.result}" alt="Pré-visualização da capa" style="max-width:200px;border-radius:8px;">`;
        };
        reader.readAsDataURL(file);
      } else {
        preview.innerHTML = "";
      }
    });
  
    // Validação simples e envio
    form.addEventListener("submit", (e) => {
      e.preventDefault();
  
      const nome = document.getElementById("nome").value.trim();
      const categoria = document.getElementById("categoria").value;
      const descricao = document.getElementById("descricao").value.trim();
  
      if (!nome || !categoria || !descricao) {
        alert("Preencha todos os campos obrigatórios!");
        return;
      }
  
      alert("Jogo cadastrado com sucesso!");
      form.reset();
      preview.innerHTML = "";
    });
  });
  