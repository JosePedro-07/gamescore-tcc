$(document).ready(function(){

    $('#BotaoCadastrar').click(function(){

        if($('#nomeCompleto').val().trim() === '' || $('#nomeCompleto').val().trim() === "Nome Completo") {
            $('#mensagem').html("Nome Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#nickUsuario').val().trim() === '' || $('#nickUsuario').val().trim() === "Nick Usuário") {
            $('#mensagem').html("Nick Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#emailUsuario').val().trim() === '' || $('#emailUsuario').val().trim() === "Email Usuário") {
            $('#mensagem').html("Email Inválido").fadeIn(300).delay(2000).fadeOut(400);//MONTAR VERIFICAÇÃO SE TEM @
        }
        else if($('#telefoneUsuario').val().trim() === '' || $('#telefoneUsuario').val().trim() === "Telefone Usuário") {
            $('#mensagem').html("Telefone Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#senha').val().trim() === '' || $('#senha').val().trim() === "Senha") {
            $('#mensagem').html("Senha Inválida").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#confirmarSenha').val().trim() === '' || $('#confirmarSenha').val().trim() === "Confirmar Senha") {
            $('#mensagem').html("Confirmar Senha Inválida").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#senha').val() !== $('#confirmarSenha').val()){
            $('#mensagem').html("Senhas não conferem").fadeIn(300).delay(2000).fadeOut(400);
        }
        else{
        no=$('#nomeCompleto').val();
        ni=$('#nickUsuario').val();
        em=$('#emailUsuario').val();
        te=$('#telefoneUsuario').val();
        se=$('#senha').val();        
        

        //$('#mensagem').html("Dados ok para cadastro");
        //$('#mensagem').fadeIn(300).delay(2000).fadeOut(400);

        $.ajax({
            url:'php/cadUsuario.php',
            type: 'POST',
            data: {nomeUsu:no, nickUsu:ni, emailUsu:em, telefoneUsu:te, senhaUsu:se},

            success: function(response) {
                
                response=response.trim();
                
                if(response !== "erro"){
                    $('#mensagem').html("Cadastrado com sucesso");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
                    setTimeout(function(){
                        $('#cadastroForm')[0].reset();
                    }, 2500);
                    setTimeout(function(){ 
                        window.location.href = "login.html";
                    }, 500);

                }else{
                    $('#mensagem').html("Erro no Cadastro");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
                }
            },
                error: function(xhr, status, error){
                    console.log("Erro na requisição: ", error);
                }
        });
    }//fim do else

});//fim do clique no botao Cadastrar


});//fim


function toggleSenha(idCampo, botao) {
    const campo = document.getElementById(idCampo);
    const img = botao.querySelector(".icone-olho");
  
    if (campo.type === "password") {
      campo.type = "text";
      img.src = "imagens/esconder.png";
      img.alt = "Esconder senha";
    } else {
      campo.type = "password";
      img.src = "imagens/mostrar.png";
      img.alt = "Mostrar senha";
    }
}