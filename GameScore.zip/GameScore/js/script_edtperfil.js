$(document).ready(function(){

    const params = new URLSearchParams(window.location.search);
    const id = params.get('idusu');

    console.log("ID encontrado na URL: " + id);
    $('#editarPerfilForm').on('submit', function(e){
        e.preventDefault();
    });

    $('#nomeEdt').click(function(){
        if($(this).val()=="Nome"){
            $(this).val('');
        }
    });

    $('#nickEdt').click(function(){
        if($(this).val()=="Nick"){
            $(this).val('');
        }
    });

    $('#emailEdt').click(function(){
        if($(this).val()=="Email"){
            $(this).val('');
        }
    });

    $('#telefoneEdt').click(function(){
        if($(this).val()=="Telefone"){
            $(this).val('');
        }
    });

    $('#senhaAtual').click(function(){
        if($(this).val()=="Senha Atual"){
            $(this).val('');
        }
    });

    $('#senhaNova').click(function(){
        if($(this).val()=="Senha Nova"){
            $(this).val('');
        }
    });

    $('#ConfirmaSenhaNova').click(function(){
        if($(this).val()=="Confirmar Senha Nova"){
            $(this).val('');
        }
    });

    $('#BotaoSalvarAlt').click(function(e){
        e.preventDefault();

        // ✅ VALIDAÇÕES OBRIGATÓRIAS
        if($('#nomeEdt').val()=='' || $('#nomeEdt').val()=="Nome"){
            mostrarMensagem("Nome inválido", "erro");
            return false;
        }
        
        if($('#nickEdt').val()=='' || $('#nickEdt').val()=="Nick"){
            mostrarMensagem("NickName inválido", "erro");
            return false;
        }
        
        if($('#emailEdt').val()=='' || $('#emailEdt').val()=="Email"){
            mostrarMensagem("Email inválido", "erro");
            return false;
        }
        
        if($('#telefoneEdt').val()=='' || $('#telefoneEdt').val()=="Telefone"){
            mostrarMensagem("Telefone inválido", "erro");
            return false;
        }
        
        if($('#senhaAtual').val()=='' || $('#senhaAtual').val()=="Senha Atual"){
            mostrarMensagem("Senha atual inválida", "erro");
            return false;
        }

        // ✅ SENHA NOVA É OPCIONAL - Só valida se foi preenchida
        let senhaNova = $('#senhaNova').val();
        let confirmaSenha = $('#ConfirmaSenhaNova').val();

        // Se a senha nova foi preenchida, valida a confirmação
        if(senhaNova !== '' && senhaNova !== "Senha Nova") {
            // ✅ Só valida a confirmação se a senha nova foi preenchida
            if(confirmaSenha === '' || confirmaSenha === "Confirmar Senha Nova"){
                mostrarMensagem("Confirme a nova senha", "erro");
                return false;
            }

            if(confirmaSenha !== senhaNova){
                mostrarMensagem("Senha e Confirmar Senha são diferentes", "erro");
                return false;
            }
        } else {
            // Se senha nova não foi preenchida, usa a senha atual
            senhaNova = $('#senhaAtual').val();
        }

        // Preparar dados
        const dados = {
            id: id,
            nome: $('#nomeEdt').val(),
            nick: $('#nickEdt').val(),
            email: $('#emailEdt').val(),
            telefone: $('#telefoneEdt').val(),
            senhaat: $('#senhaAtual').val(),
            senhanova: senhaNova // Pode ser a senha nova ou a atual
        };

        console.log("Dados enviados:", dados);
        console.log("Senha nova será:", senhaNova === $('#senhaAtual').val() ? "MESMA SENHA" : "NOVA SENHA");

        // verifica a senha atual
        $.ajax({
            url: 'php/verificaSenha.php',
            type: 'POST',
            data: { id: id, senhaat: dados.senhaat },

            success: function(response) {
                response = response.trim();
                console.log("Resposta verificaSenha:", response);

                if(response === "senha_correta") {
                    atualizarPerfil(dados);
                } else {
                    mostrarMensagem("Senha atual incorreta", "erro");
                }
            },

            error: function(xhr, status, error) {
                console.log("Erro na verificação de senha:", error);
                mostrarMensagem("Erro ao verificar senha", "erro");
            }
        });

        return false;
    });

    // Função para atualizar o perfil
    function atualizarPerfil(dados) {
        console.log("Atualizando perfil com dados:", dados);
        
        $.ajax({
            url: 'php/atualizaUsuario.php',
            type: 'POST',
            data: dados,

            success: function(response) {
                response = response.trim();
                console.log("Resposta atualizaUsuario:", response);

                if(response === "sucesso") {
                    mostrarMensagem("Dados atualizados com sucesso!", "sucesso");
                    
                    setTimeout(function(){
                        window.location.href = "editar_perfil.php?idusu=" + id;
                    }, 2000);
                    
                } else if(response === "senha_incorreta") {
                    mostrarMensagem("Senha atual incorreta", "erro");
                } else {
                    mostrarMensagem("Erro ao atualizar dados: " + response, "erro");
                }
            },

            error: function(xhr, status, error) {
                console.log("Erro na atualização:", error);
                mostrarMensagem("Erro ao atualizar perfil", "erro");
            }
        });
    }

    function mostrarMensagem(mensagem, tipo) {
        const mensagemDiv = $('#mensagem');
        mensagemDiv.text(mensagem);
        
        if(tipo === "sucesso") {
            mensagemDiv.css({
                'color': '#00ff00',
                'background-color': 'rgba(0, 255, 0, 0.1)',
                'padding': '10px',
                'border-radius': '5px',
                'display': 'block'
            });
        } else {
            mensagemDiv.css({
                'color': '#ff4444',
                'background-color': 'rgba(255, 0, 0, 0.1)',
                'padding': '10px',
                'border-radius': '5px',
                'display': 'block'
            });
        }
        
        mensagemDiv.fadeIn(300).delay(3000).fadeOut(400);
    }

});

function toggleSenha(idCampo, botao) {
    const campo = document.getElementById(idCampo);
    const img = botao.querySelector(".icone-olho");
  
    if (campo.type === "password") {
      campo.type = "text";
      img.src = "imagens/esconder.png";
      img.alt = "Esconder senha";
    } else {
      campo.type = "password";
      img.src = "imagens/mostrar.png";
      img.alt = "Mostrar senha";
    }
}