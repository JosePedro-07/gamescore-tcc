$(document).ready(function(){

    $('#nickUsuario').click(function(){
        if($(this).val()=="Usuário"){
            $(this).val('');
        }//fim do if
    }//fim da função anonima
    );//fim do click no objeto id=email

    $('#senha').click(function(){
        if($(this).val()=="Senha"){
            $(this).val('');
        }//fim do if
    }//fim da função anonima
    );//fim do click no objeto id=senha

    $('#botaoLogar').click(function(){
        if($('#nickUsuario').val()=='' || $('#nickUsuario').val()=="NickName"){
            $('#mensagem').html("NickName inválido");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }else if($('#senha').val()=='' || $('#senha').val()=="Senha"){
            $('#mensagem').html("Senha inválida");
            $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        }else{
            ni=$('#nickUsuario').val();
            se=$('#senha').val();
            //$('#mensagem').html("Usuário ok");
            //$('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
        
        $.ajax({
            url:'php/login.php',
            type: 'POST',
            data: {nickname:ni, senha:se},

            success: function(response) {
                
                response=response.trim();
                
                if(response !== "erro"){
                $('#mensagem').html("Você será redirecionado");
                $('#mensagem').fadeIn(300).delay(2000).fadeOut(200);

                var dados = response.split("|");
                var id = dados[0];
                

                window.location.href = "index.php?idusu="+id;
                //window.location.href = "index.php?idusu="+id;
                
                }else{
                    $('#mensagem').html("Usuário ou senha incorretos");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);

                }

            },

                error: function(xhr, status, error){
                    console.log("Erro na requisição:", error);

                }
            });

                
            }// fim do else
        
    });//fim do click no objeto id=botaoLoogar
});

function toggleSenha(idCampo, botao) {
    const campo = document.getElementById(idCampo);
    const img = botao.querySelector(".icone-olho");
  
    if (campo.type === "password") {
      campo.type = "text";
      img.src = "imagens/esconder.png"; // Olho cortado
      img.alt = "Esconder senha";
    } else {
      campo.type = "password";
      img.src = "imagens/mostrar.png"; // Olho aberto
      img.alt = "Mostrar senha";
    }
  }