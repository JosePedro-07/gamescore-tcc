$(document).ready(function(){

    $('#botaoCadastrarModerador').click(function(){

        if($('#nomeCompletoModera').val().trim() === '' || $('#nomeCompletoModera').val().trim() === "Nome Completo") {
            $('#mensagem').html("Nome Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#nicknameModera').val().trim() === '' || $('#nicknameModera').val().trim() === "Nick Usuário") {
            $('#mensagem').html("Nick Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#emailModera').val().trim() === '' || $('#emailModera').val().trim() === "Email Usuário") {
            $('#mensagem').html("Email Inválido").fadeIn(300).delay(2000).fadeOut(400);//MONTAR VERIFICAÇÃO SE TEM @
        }
        else if($('#telefoneModera').val().trim() === '' || $('#telefoneModera').val().trim() === "Telefone Usuário") {
            $('#mensagem').html("Telefone Inválido").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#senhaModera').val().trim() === '' || $('#senhaModera').val().trim() === "Senha") {
            $('#mensagem').html("Senha Inválida").fadeIn(300).delay(2000).fadeOut(400);
        }
        else if($('#senhaModera').val().trim() === $('#confirmarSenhaModera').val().trim()) {
            $('#mensagem').html("Senha e Confirmação não coincidem").fadeIn(300).delay(2000).fadeOut(400);
        }
        else{
        no=$('#nomeCompletoModera').val();
        ni=$('#nicknameModera').val();
        em=$('#emailModera').val();
        te=$('#telefoneModera').val();
        se=$('#senhaModera').val();

        //$('#mensagem').html("Dados ok para cadastro");
        //$('#mensagem').fadeIn(300).delay(2000).fadeOut(400);

        $.ajax({
            url:'php/cadModera.php',
            type: 'POST',
            data: {nomeUsu:no, nickUsu:ni, emailUsu:em, telefoneUsu:te, senhaUsu:se},

            success: function(response) {
                
                response=response.trim();
                
                if(response !== "erro"){
                    $('#mensagem').html("Cadastrado com sucesso");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
                    setTimeout(function(){
                        $('#cadastroForm')[0].reset();
                    }, 2500);
                    setTimeout(function(){ 
                        window.location.href = "login.html";
                    }, 500);

                }else{
                    $('#mensagem').html("Erro no Cadastro");
                    $('#mensagem').fadeIn(300).delay(2000).fadeOut(400);
                }
            },
                error: function(xhr, status, error){
                    console.log("Erro na requisição: ", error);
                }
        });
    }//fim do else

});//fim do clique no botao Cadastrar


});//fim