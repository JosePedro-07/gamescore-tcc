<?php
include "conexao.php";

$nickname = $_POST['nickname'];
$senha = $_POST['senha'];

// Prepara a consulta segura
$stmt = $conn->prepare("SELECT idusu, nickname, tipousuario FROM tbusuario WHERE nickname = ? AND senhausuario = ?");
$stmt->bind_param("ss", $nickname, $senha);

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo $row['idusu']."|".$row['nickname']."|".$row['tipousuario'];
} else {
    echo "erro";
}

$stmt->close();
$conn->close();
?>
