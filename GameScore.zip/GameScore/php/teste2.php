<?php
$apiKey = "EC297DD7C0D1A66FD2FEE64ED0791F6F"; // Sua chave Steam API
$search = $_GET['q'] ?? '';
$resultados = [];

// Função para buscar lista de todos os apps (poderíamos cachear para otimizar)
function getAppList() {
    $url = "https://api.steampowered.com/ISteamApps/GetAppList/v2/";
    $resposta = file_get_contents($url);
    $dados = json_decode($resposta, true);
    return $dados['applist']['apps'] ?? [];
}

// Função para buscar detalhes do jogo pelo AppID
function getGameDetails($appId) {
    $url = "https://store.steampowered.com/api/appdetails?appids=$appId&l=portuguese";
    $resposta = file_get_contents($url);
    $dados = json_decode($resposta, true);
    return $dados[$appId]['data'] ?? null;
}

// Se houver busca
if (!empty($search)) {
    $apps = getAppList();
    foreach ($apps as $app) {
        if (stripos($app['name'], $search) !== false) {
            $resultados[] = $app;
            if (count($resultados) >= 5) break; // Limita a 5 resultados
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Busca de Jogos (Steam API)</title>
<style>
body { font-family: Arial, sans-serif; max-width: 900px; margin: 30px auto; }
form { margin-bottom: 20px; }
.game { margin-bottom: 20px; padding: 10px; border: 1px solid #ccc; border-radius: 8px; display: flex; gap: 15px; }
img { width: 150px; height: 100px; object-fit: cover; border-radius: 5px; }
h2 { margin: 0; font-size: 18px; }
p { margin: 5px 0; }
.descricao { font-size: 14px; color: #333; }
</style>
</head>
<body>
<h1>Busca de Jogos (Steam API)</h1>
<form method="get" action="">
    <input type="text" name="q" placeholder="Digite o nome do jogo" value="<?=htmlspecialchars($search)?>" style="width:60%; padding:8px;">
    <button type="submit" style="padding:8px;">Buscar</button>
</form>

<?php if(!empty($search)): ?>
    <h2>Resultados para "<?=htmlspecialchars($search)?>"</h2>
    <?php if(empty($resultados)): ?>
        <p>Nenhum jogo encontrado.</p>
    <?php else: ?>
        <?php foreach($resultados as $jogo): ?>
            <?php
            $detalhes = getGameDetails($jogo['appid']);
            if ($detalhes):
                $nome = $detalhes['name'] ?? 'Sem nome';
                $descricao = strip_tags($detalhes['short_description'] ?? 'Sem descrição.');
                $imagem = $detalhes['header_image'] ?? 'https://via.placeholder.com/150x100?text=Sem+Capa';
                $preco = $detalhes['is_free'] ? 'Gratuito' : ($detalhes['price_overview']['final_formatted'] ?? 'Preço indisponível');
                $link = "https://store.steampowered.com/app/{$jogo['appid']}";
            ?>
            <div class="game">
                <img src="<?=htmlspecialchars($imagem)?>" alt="Capa">
                <div>
                    <h2><?=htmlspecialchars($nome)?></h2>
                    <p><strong>Preço:</strong> <?=htmlspecialchars($preco)?></p>
                    <p class="descricao"><strong>Descrição:</strong> <?=htmlspecialchars($descricao)?></p>
                    <p><a href="<?=htmlspecialchars($link)?>" target="_blank">Ver na Steam</a></p>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
    <?php endif; ?>
<?php endif; ?>
</body>
</html>
