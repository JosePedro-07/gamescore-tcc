<?php
header('Content-Type: application/json');

$url = "https://api.steampowered.com/ISteamApps/GetAppList/v2/";
$resp = @file_get_contents($url);
if (!$resp) {
    echo json_encode([]);
    exit;
}

$data = json_decode($resp, true);
$apps = $data['applist']['apps'] ?? [];

// parâmetros de paginação
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;

$fatias = array_slice($apps, $offset, $limit);

echo json_encode($fatias, JSON_UNESCAPED_UNICODE);
