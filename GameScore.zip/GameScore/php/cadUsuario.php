<?php
include "conexao.php";

$emailUsu = $conn->real_escape_string($_POST['emailUsu']);
$senhaUsu = $conn->real_escape_string($_POST['senhaUsu']);
$telefoneUsu = $conn->real_escape_string($_POST['telefoneUsu']);
$nomeUsu = $conn->real_escape_string($_POST['nomeUsu']);
$nickUsu = $conn->real_escape_string($_POST['nickUsu']);

$comandoSql = "INSERT INTO tbusuario 
(emailusuario, senhausuario, telefoneusuario, nomeusuario, nickname, tipousuario) 
VALUES ('$emailUsu', '$senhaUsu', '$telefoneUsu', '$nomeUsu', '$nickUsu', 0)";

$result = $conn->query($comandoSql); 
if ($result) { 
    echo "sucesso"; 
} else { 
    echo "erro"; 
}

$conn->close(); 
?>
