<?php
    //Conexão Usuario
    $host = "localhost";
    $user = "root";
    $password = "";
    $dbname = "bdsitejogostcc";

    $conn = new mysqli($host, $user, $password, $dbname);

    //Verificar Conexão
    /*if($conn ->connect_error){
        die("Conexão falhou: " . $conn->connect_error);
    }
    else {
        echo "Conexão Ok";
    }*/

?>