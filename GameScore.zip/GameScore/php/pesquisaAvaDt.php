<?php
 /*1-incluir a conexao*/
 include "conexao.php";

 /*2-pegando o id do usuario vindo pela url */
 $codjogo=$_GET["appId"];

 /*3-criando o comando sql para pegar os dados do usuario que logou */
 $comandoSql = "SELECT RECOMENDACAO, AVALIACAO FROM tbavaliacao WHERE CODJOGO=$codjogo";

 /*4- executando o comando sql criado acima e pegando o resultado*/
 $result = $conn->query($comandoSql);
 if ($result-> num_rows > 0){
$row = $result->fetch_assoc();

$recomendacao=$row["RECOMENDACAO"];
$avaliacao=$row["AVALIACAO"];

 }
 
?>