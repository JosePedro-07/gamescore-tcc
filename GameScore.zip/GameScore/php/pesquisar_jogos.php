<?php
header('Content-Type: application/json; charset=utf-8');

// Ativar exibição de erros (apenas para desenvolvimento)
error_reporting(E_ALL);
ini_set('display_errors', 1);

$idusu = isset($_GET['idusu']) ? intval($_GET['idusu']) : null;
$termo = isset($_GET['termo']) ? trim($_GET['termo']) : '';

if (empty($termo)) {
    echo json_encode(['success' => false, 'message' => 'Termo de pesquisa vazio']);
    exit;
}

function pesquisarJogosSteam($termo) {
    $url = "https://store.steampowered.com/api/storesearch/?term=" . urlencode($termo) . "&l=portuguese&cc=BR";
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'GameScoreBot/1.0 (+https://localhost)',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    
    $resp = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    
    if ($status !== 200 || !$resp) {
        return ['success' => false, 'message' => 'Erro ao conectar com a Steam'];
    }
    
    $json = json_decode($resp, true);
    if (!is_array($json) || !isset($json['items'])) {
        return ['success' => false, 'message' => 'Resposta inválida da Steam'];
    }
    
    return ['success' => true, 'items' => $json['items']];
}

function filtrarApenasJogos($items) {
    $jogosFiltrados = [];
    
    foreach ($items as $item) {
        $type = strtolower($item['type'] ?? '');
        
        // Filtra apenas jogos (exclui DLC, software, hardware, etc)
        $tiposExcluidos = ['dlc', 'demo', 'mod', 'video', 'advertising', 'application', 'tool', 'hardware', 'series', 'episode', 'season'];
        
        if (!in_array($type, $tiposExcluidos)) {
            // Verifica se tem imagem válida
            $imagem = $item['tiny_image'] ?? $item['image'] ?? null;
            
            if ($imagem && filter_var($imagem, FILTER_VALIDATE_URL)) {
                $jogosFiltrados[] = [
                    'id' => $item['id'],
                    'nome' => $item['name'],
                    'imagem' => $imagem,
                    'link' => "https://store.steampowered.com/app/" . $item['id'] . "/"
                ];
            }
        }
        
        // Limita a 20 resultados
        if (count($jogosFiltrados) >= 20) {
            break;
        }
    }
    
    return $jogosFiltrados;
}

try {
    $resultado = pesquisarJogosSteam($termo);
    
    if (!$resultado['success']) {
        echo json_encode($resultado);
        exit;
    }
    
    $jogos = filtrarApenasJogos($resultado['items']);
    
    // Adiciona o idusu aos links
    foreach ($jogos as &$jogo) {
        $jogo['link'] = "detalhes.php?appId=" . $jogo['id'] . "&idusu=" . $idusu;
    }
    
    echo json_encode([
        'success' => true,
        'jogos' => $jogos,
        'termo' => $termo,
        'total' => count($jogos)
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro na pesquisa: ' . $e->getMessage()
    ]);
}
?>