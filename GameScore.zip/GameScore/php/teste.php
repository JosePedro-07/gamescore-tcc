<?php
// Nome do jogo que você quer buscar
$nomeJogo = $_GET['q'] ?? 'Dodge 2';

// 1️⃣ Buscar pelo nome usando storesearch
$searchUrl = "https://store.steampowered.com/api/storesearch/?term=" . urlencode($nomeJogo) . "&cc=br&l=portuguese";
$searchResponse = file_get_contents($searchUrl);
$searchData = json_decode($searchResponse, true);

// Verificar se achou algum resultado
if (!empty($searchData['items'][0])) {
    $primeiroJogo = $searchData['items'][0];
    $appId = $primeiroJogo['id'];

    // 2️⃣ Pegar detalhes do jogo
    $detailsUrl = "https://store.steampowered.com/api/appdetails?appids=$appId&l=portuguese";
    $detailsResponse = file_get_contents($detailsUrl);
    $detailsData = json_decode($detailsResponse, true);

    if (!empty($detailsData[$appId]['success'])) {
        $info = $detailsData[$appId]['data'];
        echo "<h2>" . htmlspecialchars($info['name']) . "</h2>";
        echo "<img src='" . htmlspecialchars($info['header_image']) . "' alt='Capa'><br>";
        echo "<p>" . strip_tags($info['short_description']) . "</p>";
    } else {
        echo "<p>Detalhes do jogo não encontrados.</p>";
    }
} else {
    echo "<p>Jogo não encontrado.</p>";
}
?>

<!-- Formulário simples para buscar outro jogo -->
<form method="get" action="">
    <input type="text" name="q" placeholder="Digite o nome do jogo" value="<?=htmlspecialchars($nomeJogo)?>">
    <button type="submit">Buscar</button>
</form>
