<?php
include "conexao.php";

$emailmod = $conn->real_escape_string($_POST['emailmod']);
$senhamod = $conn->real_escape_string($_POST['senhamod']);
$telmod = $conn->real_escape_string($_POST['telmod']);
$nomemod = $conn->real_escape_string($_POST['nomemod']);
$nickmod = $conn->real_escape_string($_POST['nickmod']);

$comandoSql = "INSERT INTO tbusuario 
(emailusuario, senhausuario, telefoneusuario, nomeusuario, nickname, tipousuario) 
VALUES ('$emailmod', '$senhamod', '$telmod', '$nomemod', '$nickmod', 2)";

$result = $conn->query($comandoSql); 
if ($result) { 
    echo "sucesso"; 
} else { 
    echo "erro"; 
}

$conn->close(); 
?>
