<?php
include "conexao.php";

$email = $_POST['email'] ?? null;
$senhanova = $_POST['senhanova'] ?? null;
$telefone = $_POST['telefone'] ?? null;
$nome = $_POST['nome'] ?? null;
$nick = $_POST['nick'] ?? null;
$idusu = $_POST['id'] ?? null;
$senhaat = $_POST['senhaat'] ?? null;

if ($idusu && $senhaat) { // só continua se id e senha atual existirem

    // Atualizar email
    if ($email) {
        $stmt = $conn->prepare("UPDATE tbusuario SET emailusuario=? WHERE idusu=? AND SENHAUSUARIO=?");
        $stmt->bind_param("sis", $email, $idusu, $senhaat);
        $stmt->execute();
        $stmt->close();
    }

    // Atualizar telefone
    if ($telefone) {
        $stmt = $conn->prepare("UPDATE tbusuario SET telefoneusuario=? WHERE idusu=? AND SENHAUSUARIO=?");
        $stmt->bind_param("sis", $telefone, $idusu, $senhaat);
        $stmt->execute();
        $stmt->close();
    }

    // Atualizar nome
    if ($nome) {
        $stmt = $conn->prepare("UPDATE tbusuario SET nomeusuario=? WHERE idusu=? AND SENHAUSUARIO=?");
        $stmt->bind_param("sis", $nome, $idusu, $senhaat);
        $stmt->execute();
        $stmt->close();
    }

    // Atualizar nickname
    if ($nick) {
        $stmt = $conn->prepare("UPDATE tbusuario SET nickname=? WHERE idusu=? AND SENHAUSUARIO=?");
        $stmt->bind_param("sis", $nick, $idusu, $senhaat);
        $stmt->execute();
        $stmt->close();
    }

    // Atualizar senha
    if ($senhanova) {
        $stmt = $conn->prepare("UPDATE tbusuario SET senhausuario=? WHERE idusu=? AND SENHAUSUARIO=?");
        $stmt->bind_param("sis", $senhanova, $idusu, $senhaat);
        $stmt->execute();
        $stmt->close();
    }

    echo "sucesso";

} else {
    echo "erro";
}

$conn->close();
?>
