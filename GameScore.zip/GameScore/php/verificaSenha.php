<?php
include "conexao.php";

$idusu = $_POST['id'];
$senhaat = $_POST['senhaat'];

// Consulta segura
$stmt = $conn->prepare("SELECT idusu FROM tbusuario WHERE idusu = ? AND senhausuario = ?");
$stmt->bind_param("ss", $idusu, $senhaat);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "senha_correta";
} else {
    echo "senha_incorreta";
}

$stmt->close();
$conn->close();
?>
