<?php
include "conexao.php";

$idusu = $_POST['idusu'] ?? null;
$appId = $_POST['appId'] ?? null;
$recomendacao = $_POST['recomendacao'] ?? null;
$avaliacao = $_POST['avaliacao'] ?? null;

if (!$idusu || !$appId || !$recomendacao || !$avaliacao) {
    exit("erro");
}

$stmt = $conn->prepare("
    INSERT INTO tbavaliacao (CODUSUARIO, CODJOGO, RECOMENDACAO, AVALIACAO)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param("iisi", $idusu, $appId, $recomendacao, $avaliacao);

if ($stmt->execute()) {
    echo "sucesso";
} else {
    echo "erro";
}

$stmt->close();
$conn->close();
?>
