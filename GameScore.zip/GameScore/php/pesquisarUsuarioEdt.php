<?php
/* 1 - Incluir a conexão */
include "conexao.php";

/* 2 - Pegando o id do usuário vindo pela URL */
$idusu = $_GET["idusu"];

/* 3 - Criando o comando SQL para pegar os dados do usuário */
$comandoSql = "SELECT EMAILUSUARIO, SENHAUSUARIO, TELEFONEUSUARIO, NOMEUSUARIO, NICKNAME, TIPOUSUARIO FROM tbusuario WHERE idusu=$idusu";

/* 4 - Executando o comando SQL e pegando o resultado */
$result = $conn->query($comandoSql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $email = $row["EMAILUSUARIO"];
    $senha = $row["SENHAUSUARIO"];
    $telefone = $row["TELEFONEUSUARIO"];
    $nome = $row["NOMEUSUARIO"];
    $nickname = $row["NICKNAME"];
    $tipo = $row["TIPOUSUARIO"];

    // Pegar a primeira letra do nickname
    $primeiraLetra = $nickname ? strtoupper(mb_substr($nickname, 0, 1)) : '';
}
?>

<form id="editarUsuario" method="post" action="salvar_usuario.php">
    <div>
        <label for="nomeEdt">Nome completo</label>
        <input type="text" id="nomeEdt" name="nomeEdt" placeholder="Seu nome completo" value="<?= htmlspecialchars($nome) ?>" maxlength="100" required />
    </div>

    <div>
        <label for="nickEdt">NickName</label>
        <input type="text" id="nickEdt" name="nickEdt" placeholder="Seu NickName" value="<?= htmlspecialchars($nickname) ?>" maxlength="50" required />
    </div>

    <div>
        <label for="emailEdt">E-mail</label>
        <input type="email" id="emailEdt" name="emailEdt" placeholder="seu@email.com" value="<?= htmlspecialchars($email) ?>" maxlength="64" required />
    </div>

    <div>
        <label for="telefoneEdt">Telefone</label>
        <input type="tel" id="telefoneEdt" name="telefoneEdt" placeholder="(11)91234-5678" maxlength="15" value="<?= htmlspecialchars($telefone) ?>" required />
    </div>

    <div>
        <label for="senhaAtual">Senha Atual</label>
        <div class="input-group senha-group">
            <input type="password" id="senhaAtual" name="senhaAtual" placeholder="Digite a senha Atual" maxlength="25" />
            <button type="button" class="toggle-senha" onclick="toggleSenha('senhaAtual', this)" aria-label="Mostrar ou ocultar senha">
                <img src="imagens/mostrar.png" alt="Mostrar senha" class="icone-olho">
            </button>
        </div>
        <div class="forgot">
        <a href="esqueci_senha.php" tabindex="0">Esqueceu a senha?</a>
      </div>
    </div>

    <div>
        <label for="senhaNova">Nova Senha</label>
        <div class="input-group senha-group">
            <input type="password" id="senhaNova" name="senhaNova" placeholder="Digite uma nova senha" maxlength="25" />
            <button type="button" class="toggle-senha" onclick="toggleSenha('senhaNova', this)" aria-label="Mostrar ou ocultar senha">
                <img src="imagens/mostrar.png" alt="Mostrar senha" class="icone-olho">
            </button>
        </div>
    </div>

    <div>
        <label for="ConfirmaSenhaNova">Confirme a Nova Senha</label>
        <div class="input-group senha-group">
            <input type="password" id="ConfirmaSenhaNova" name="ConfirmaSenhaNova" placeholder="Confirme a sua senha" maxlength="25" />
            <button type="button" class="toggle-senha" onclick="toggleSenha('ConfirmaSenhaNova', this)" aria-label="Mostrar ou ocultar senha">
                <img src="imagens/mostrar.png" alt="Mostrar senha" class="icone-olho">
            </button>
        </div>
    </div>
</form>
