<?php
include "conexao.php";

$nickname = $_POST['nickname'];
$senha = $_POST['senha'];


$comandoSql = "SELECT idusu, nickname, tipousuario FROM tbusuario
WHERE nickname = '$nickname' and senhausuario='$senha'";

$result = $conn->query($comandoSql);

if($result-> num_rows > 0){
    $row = $result->fetch_assoc();

    echo $row['idusu']."|".$row['nickname']."|".$row['tipousuario'];
} else{

    echo"erro";
}

$conn->close();

?>