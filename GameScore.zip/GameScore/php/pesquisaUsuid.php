<?php
 /*1-incluir a conexao*/
 include "conexao.php";

 /*2-pegando o id do usuario vindo pela url */
 $idusu=$_GET["idusu"];

 /*3-criando o comando sql para pegar os dados do usuario que logou */
 $comandoSql = "SELECT NICKNAME, TIPOUSUARIO FROM tbusuario WHERE idusu=$idusu";

 /*4- executando o comando sql criado acima e pegando o resultado*/
 $result = $conn->query($comandoSql);
 if ($result-> num_rows > 0){
$row = $result->fetch_assoc();

$nickname=$row["NICKNAME"];
$tipo=$row["TIPOUSUARIO"];

//pegar a primeira letra do nickname
$primeiraLetra = $nickname ? strtoupper(mb_substr($nickname, 0, 1)) : '';
 }
 
?>