<?php
 /*1-incluir a conexao*/
 include "conexao.php";

 /*2-pegando o id do usuario e da avaliação vindo pela url */
 $idusuava=$_GET["idAva"];
 $idusuUsu=$_GET["idusu"];

 /*3-criando o comando sql para pegar os dados do usuario que logou */
 $comandoSql = "DELETE FROM tbavaliacao WHERE IDAVA=$idusuava";

 /*4- executando o comando sql criado acima e pegando o resultado*/
 $conn->query($comandoSql);

header("Location: ../gerenciar_resenhas_gerais.php?idusu=" . $idusuUsu);
exit; // garante que o script pare aqui

?>