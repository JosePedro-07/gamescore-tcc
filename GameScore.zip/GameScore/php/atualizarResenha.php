<?php
include "conexao.php";

$idava = $_POST['idava'] ?? null;
$recomendacao = $_POST['recomendacao'] ?? null;
$avaliacao = $_POST['avaliacao'] ?? null;


if ($idava && $recomendacao && $avaliacao) { // só continua se idava, recomendação e avaliação existirem

    // Atualizar recomendação
    if ($idava) {
        $stmt = $conn->prepare("UPDATE tbavaliacao SET RECOMENDACAO=? WHERE IDAVA=?");
        $stmt->bind_param("si", $recomendacao, $idava);
        $stmt->execute();
        $stmt->close();
    }

    // Atualizar avaliação
    if ($idava) {
        $stmt = $conn->prepare("UPDATE tbavaliacao SET AVALIACAO=? WHERE IDAVA=?");
        $stmt->bind_param("si", $avaliacao, $idava);
        $stmt->execute();
        $stmt->close();
    }

    echo "sucesso";

} else {
    echo "erro";
}

$conn->close();
?>
