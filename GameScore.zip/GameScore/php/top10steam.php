<?php/* 6 - Pegar os top 10 jogos mais jogados da Steam */
$steamApiKey = "EC297DD7C0D1A66FD2FEE64ED0791F6F";
$topJogos = [];

// Endpoint Steam API
$urlTop = "https://api.steampowered.com/ISteamCharts/GetMostPlayedGames/v1/";
$resposta = file_get_contents($urlTop);
$dados = json_decode($resposta, true);

if (!empty($dados['response']['ranks'])) {
    $ranks = array_slice($dados['response']['ranks'], 0, 10); // Top 10
    foreach ($ranks as $item) {
        $appId = $item['appid'];

        // Buscar detalhes do jogo em português
        $urlDetalhes = "https://store.steampowered.com/api/appdetails?appids=$appId&l=portuguese";
        $detalhesJson = file_get_contents($urlDetalhes);
        $detalhes = json_decode($detalhesJson, true);

        if (!empty($detalhes[$appId]['success']) && !empty($detalhes[$appId]['data'])) {
            $jogo = $detalhes[$appId]['data'];
            $topJogos[] = [
                'nome' => $jogo['name'] ?? 'Sem nome',
                'imagem' => $jogo['header_image'] ?? 'https://via.placeholder.com/200x100?text=Sem+Capa',
                'link' => "https://store.steampowered.com/app/$appId"
            ];
        }
    }
}
?>