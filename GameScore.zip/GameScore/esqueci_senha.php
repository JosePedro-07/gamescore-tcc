<?php
include "php/conexao.php";

// PHPMailer
require "phpmailer/src/PHPMailer.php";
require "phpmailer/src/SMTP.php";
require "phpmailer/src/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Função para enviar e-mail
function enviarEmail($email, $token) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'suportegscore@gmail.com';
        $mail->Password   = 'iqsonmobvqbdwcwb'; // use App Password do Gmail
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        $mail->CharSet = 'UTF-8';
        $mail->setLanguage('pt');

        $mail->setFrom('suportegscore@gmail.com', 'GameScore');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Redefinição de Senha - GameScore';
        $mail->Body    = "Clique no link abaixo para redefinir sua senha:<br><br>
                          <a href='http://localhost/GameScore/redefinir_senha.php?token=$token'>Redefinir Senha</a><br><br>
                          Este link expira em 1 hora.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// ==============================
// PROCESSAMENTO: ESQUECI A SENHA
// ==============================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    $sql = "SELECT IDUSU FROM tbusuario WHERE EMAILUSUARIO = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $user = $resultado->fetch_assoc();
        $token = bin2hex(random_bytes(50));
        $expira = date("Y-m-d H:i:s", strtotime("+1 hour"));

        $sql = "UPDATE tbusuario SET reset_token = ?, reset_expira = ? WHERE IDUSU = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $token, $expira, $user['IDUSU']);
        $stmt->execute();

        if (enviarEmail($email, $token)) {
            $msg = "Um e-mail foi enviado para $email com o link de redefinição.";
        } else {
            $msg = "Erro ao enviar e-mail!";
        }
    } else {
        $msg = "E-mail não encontrado!";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>Esqueci a Senha - GamesCore</title>
  <link rel="stylesheet" href="css/style_geral.css" />
  <link rel="stylesheet" href="css/style_esqueci_senha.css" />
</head>
<body>
  <header>
    <img src="imagens/controle_ret.png" alt="Ícone de controle de videogame" class="logo-pequena" />
    <h1><img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" /></h1>
  </header>

  <main>
    <button id="btnVoltar" onclick="window.history.back()">← Voltar</button>
    <h1>Esqueci a Senha</h1>

    <?php if (isset($msg)) echo "<p>$msg</p>"; ?>

    <form method="POST">
      <label for="email">Digite seu e-mail cadastrado:</label>
      <input type="email" name="email" id="email" required>
      <button type="submit">Enviar link de redefinição</button>
    </form>
  </main>
</body>
</html>
