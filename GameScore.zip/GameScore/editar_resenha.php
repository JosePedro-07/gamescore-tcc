<?php
// Conexão com o banco
include "php/conexao.php";

// Verifica se veio um ID de usuário na URL
$idAva = null;
$idusu = null;
$recomendacao = '';
$avaliacao = 0;
$nickname = '';
$tipo = 0;
$primeiraLetra = '';

if (isset($_GET["idAva"]) && is_numeric($_GET["idAva"])) {
    $idAva = intval($_GET["idAva"]);

    $comandoSql = "SELECT RECOMENDACAO, AVALIACAO FROM tbavaliacao WHERE IDAVA = ?";
    
    if ($stmt = $conn->prepare($comandoSql)) {
        $stmt->bind_param("i", $idAva);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $recomendacao = $row["RECOMENDACAO"] ?? '';
            $avaliacao = $row["AVALIACAO"] ?? 0;
        }
        $stmt->close();
    }
}

if (isset($_GET["idusu"]) && is_numeric($_GET["idusu"])) {
    $idusu = intval($_GET["idusu"]);

    $comandoSql = "SELECT NICKNAME, TIPOUSUARIO FROM tbusuario WHERE idusu = ?";
    
    if ($stmt = $conn->prepare($comandoSql)) {
        $stmt->bind_param("i", $idusu);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $nickname = $row["NICKNAME"] ?? '';
            $tipo = $row["TIPOUSUARIO"] ?? 0;
            $primeiraLetra = $nickname ? strtoupper(mb_substr($nickname, 0, 1)) : '';
        }
        $stmt->close();
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GamesCore - Editar Resenha</title>
  <link rel="stylesheet" href="css/style_geral.css" />
  <link rel="stylesheet" href="css/style_gerenciar_resenhas.css" />
  <link rel="stylesheet" href="css/style_edt_resenha.css" />
  <link rel="icon" href="imagens/controle_top.png" type="image/png">  
</head>
<body>

<header>
  <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
    <img src="imagens/controle_ret.png" alt="Ícone de controle de videogame" class="logo-pequena" />
  </a>
  <h1>
    <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      <img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" />
    </a>
  </h1>

  <div class="header-opcoes">
    <?php if (!empty($idusu)): ?>
      <div class="usuario-logado" id="usuarioLogado">
        <div class="avatar-usuario"><?= htmlspecialchars($primeiraLetra) ?></div>
        <span class="nome-usuario">
          <?php
            if ($tipo == 0):
              echo "Olá, " . htmlspecialchars($nickname);
            elseif ($tipo == 1):
              echo "Olá Admin, " . htmlspecialchars($nickname);
            elseif ($tipo == 2):
              echo "Olá Moderador, " . htmlspecialchars($nickname);
            endif;
          ?>
        </span>
        <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
          <?php if ($tipo == 1): ?>
            <button role="menuitem" onclick="cadastrarModera(<?= $idusu ?>)">Cadastrar Moderador</button>
            
            <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php elseif ($tipo == 2): ?>
            
            <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php endif; ?>
          <button role="menuitem" onclick="gerenciarResenhas(<?= $idusu ?>)">Gerenciar Resenhas</button>
          <button role="menuitem" onclick="editarPerfil(<?= $idusu ?>)">Editar Perfil</button>
          <button role="menuitem" onclick="window.location.href='php/logout.php'">Sair</button>
        </div>
      </div>
    <?php else: ?>
      <div class="usuario-logado">
        <button onclick="window.location.href='login.html'" class="botao-login">Fazer Login</button>
      </div>
    <?php endif; ?>
  </div>
</header>

<main>
  <button id="btnVoltar" role="menuitem" onclick="window.location.href='gerenciar_resenhas.php?idusu=<?= (int)$idusu ?>'">
    ← Voltar
  </button>

  <h1>Editar Resenha</h1>

  <form id="cadastroForm" onsubmit="event.preventDefault();">
      <div class="input-group">
        <label for="Recomendacao">Recomendação:</label>
        <textarea id="Recomendacao" name="Recomendacao" placeholder="Digite sua recomendação..." required rows="5"><?= htmlspecialchars($recomendacao) ?></textarea>
      </div>
      
      <div class="input-group">
        <label>Avaliação:</label>
        <div id="rating" class="stars">
          <span data-value="1">☆</span>
          <span data-value="2">☆</span>
          <span data-value="3">☆</span>
          <span data-value="4">☆</span>
          <span data-value="5">☆</span>
        </div>
        <input type="hidden" id="Avaliacao" name="Avaliacao" value="<?= (int)$avaliacao ?>">
      </div>

      <div class="botoes-acao">
        <button type="submit" class="btn-alterar" id="BotaoAlterarResenha">Alterar Resenha</button>
      </div>
  </form>
  
  <div id="mensagem" style="display: none; color: white; text-align: center; margin-top: 15px;"></div>
</main>

<script>
// Passa os valores do PHP para o JS
const ia = <?= (int)$idAva ?>;   // id da avaliação
const idusu = <?= (int)$idusu ?>; // id do usuário
const avaliacaoInicial = <?= (int)$avaliacao ?>;

// Inicializar estrelas quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
    // Pintar as estrelas baseado na avaliação inicial
    if (avaliacaoInicial > 0) {
        pintarEstrelas(avaliacaoInicial);
    }
    
    // Configurar eventos das estrelas
    const stars = document.querySelectorAll('#rating span');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            const value = parseInt(this.getAttribute('data-value'));
            document.getElementById('Avaliacao').value = value;
            pintarEstrelas(value);
        });
        
        star.addEventListener('mouseover', function() {
            const value = parseInt(this.getAttribute('data-value'));
            pintarEstrelas(value);
        });
        
        star.addEventListener('mouseout', function() {
            const currentValue = parseInt(document.getElementById('Avaliacao').value);
            pintarEstrelas(currentValue);
        });
    });
});

function pintarEstrelas(valor) {
    const stars = document.querySelectorAll('#rating span');
    stars.forEach((star, index) => {
        if (index < valor) {
            star.textContent = '★';
            star.style.color = '#ffcc00';
        } else {
            star.textContent = '☆';
            star.style.color = '#ccc';
        }
    });
}

// Funções do menu
function cadastrarModera(idusu) {
    window.location.href = 'cadastro_modera.php?idusu=' + idusu;
}

function cadastrarJogo(idusu) {
    window.location.href = 'cadastro_jogo.php?idusu=' + idusu;
}

function gerenciarResenhasGerais(idusu) {
    window.location.href = 'gerenciar_resenhas_gerais.php?idusu=' + idusu;
}

function gerenciarResenhas(idusu) {
    window.location.href = 'gerenciar_resenhas.php?idusu=' + idusu;
}

function editarPerfil(idusu) {
    window.location.href = 'editar_perfil.php?idusu=' + idusu;
}
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="js/script_Alt_Resenha.js"></script>
<script src="js/script.js"></script>
<script src="js/script_carrossel.js"></script>

</body>
</html>