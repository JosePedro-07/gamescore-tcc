<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GameScore</title>
  <link rel="stylesheet" href="css/style_geral.css"/>
  <link rel="stylesheet" href="css/style_cadastro_jogo.css"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="icon" href="imagens/controle_top.png" type="image/png">
</head>
<body>

  <?php include "php/pesquisausUid.php";?>

<header>
    <a onclick="VoltarIndex(<?= (int)$idusuUsuUsu ?>)">
  </h1>

  <div class="header-opcoes">

<div class="usuario-logado" id="usuarioLogado">
    <div class="avatar-usuario"><?= $primeiraLetra ?></div>
    <span class="nome-usuario">
      <?php
        if ($tipo == 0):
          echo " Olá, " . htmlspecialchars($nickname);
        elseif ($tipo == 1):
          echo " Olá Admin, " . htmlspecialchars($nickname);
        elseif ($tipo == 2):
          echo " Olá Moderador, " . htmlspecialchars($nickname);
        endif;?>
        </span>
  
  <!-- Botões divididos por tipo de usuario-->
  <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
            <?php if ($tipo == 1): // ADMIN ?>
              <button role="menuitem" onclick="cadastrarModera(<?= $idusuUsu ?>)">Cadastrar Moderador</button>
              <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
            <?php elseif ($tipo == 2): // MODERADOR ?>
              <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
            <?php endif; ?>

            <!-- Botões comuns a todos os usuários logados -->
            <button role="menuitem" onclick="gerenciarResenhas(<?= $idusu ?>)">Gerenciar Resenhas</button>
            <button role="menuitem" onclick="editarPerfil(<?= $idusu ?>)">Editar Perfil</button>
            <button role="menuitem" onclick="window.location.href='php/logout.php'">Sair</button>
          </div>
        </div>

      
    </div>
  </header>

<div class="login-body">
  <main class="login-box" role="main" aria-label="Formulário de cadastro">  
    <button id="btnVoltar" onclick="window.history.back()">← Voltar</button>
    <h1>Cadastro de Jogo</h1>
    <h2>GameScore</h2>

    <form id="formCadastroJogo" enctype="multipart/form-data">
      <div class="input-group">
        <input type="text" id="nome" name="nome" placeholder="Nome do Jogo" required>
      </div>

      <div class="input-group">
        <select id="categoria" name="categoria" required>
          <option value="">Selecione a categoria...</option>
          <option value="ação">Ação</option>
          <option value="aventura">Aventura</option>
          <option value="rpg">RPG</option>
          <option value="esporte">Esporte</option>
          <option value="estratégia">Estratégia</option>
        </select>
      </div>

      <div class="input-group">
        <input type="file" id="capa" name="capa" accept="image/*" required>
        <div id="previewCapa" class="preview"></div>
      </div>

      <div class="input-group">
        <textarea id="descricao" name="descricao" placeholder="Descrição do jogo" rows="4" required></textarea>
      </div>

      <button type="submit" class="login-btn">Cadastrar</button>
    </form>
  </main>
</div>

<script src="js/script_cadastro_jogo.js"></script>
<script src="js/script.js"></script>
</body>
</html>
