<?php
// Conexão com o banco
include "php/conexao.php";

$avaliacoes = [];
$idusu = $_GET["idusu"] ?? 0;

if ($idusu > 0) {
    // ✅ CONSULTA CORRIGIDA - AppId instead of IDJOGO
    $comandoSql = "
        SELECT a.IDAVA, a.RECOMENDACAO, a.AVALIACAO, j.NOMEJOGO
        FROM tbavaliacao a
        JOIN tbjogo j ON a.CODJOGO = j.AppId
        WHERE a.CODUSUARIO = ?
    ";

    if ($stmt = $conn->prepare($comandoSql)) {
        $stmt->bind_param("i", $idusu);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $avaliacoes[] = $row;
            }
        }
        $stmt->close();
    }
}

// Dados do usuário logado
include "php/pesquisausUid.php";
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GamesCore</title>
  <link rel="icon" href="imagens/controle_top.png" type="image/png">
  <link rel="stylesheet" href="css/style_geral.css" />
  <link rel="stylesheet" href="css/style_gerenciar_resenhas.css" />
</head>
<body>

<header>
  <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
    <img src="imagens/controle_ret.png" alt="Ícone de controle de videogame" class="logo-pequena" />
  </a>
  <h1>
    <a onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      <img src="imagens/escrita_top.png" alt="Logo GamesCore" class="logo-pequena-escrita" />
    </a>
  </h1>

  <div class="header-opcoes">
    <?php if (!empty($idusu)): ?>
      <div class="usuario-logado" id="usuarioLogado">
        <div class="avatar-usuario"><?= $primeiraLetra ?></div>
        <span class="nome-usuario">
          <?php
            if ($tipo == 0):
              echo "Olá, " . htmlspecialchars($nickname);
            elseif ($tipo == 1):
              echo "Olá Admin, " . htmlspecialchars($nickname);
            elseif ($tipo == 2):
              echo "Olá Moderador, " . htmlspecialchars($nickname);
            endif;
          ?>
        </span>
        <div class="menu-usuario" id="menuUsuario" role="menu" aria-hidden="true">
          <?php if ($tipo == 1): ?>
            <button role="menuitem" onclick="cadastrarModera(<?= $idusu ?>)">Cadastrar Moderador</button>
            
            <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php elseif ($tipo == 2): ?>
            
            <button role="menuitem" onclick="gerenciarResenhasGerais(<?= $idusu ?>)">Gerenciar Resenhas Gerais</button>
          <?php endif; ?>
          <button role="menuitem" onclick="editarPerfil(<?= $idusu ?>)">Editar Perfil</button>
          <button role="menuitem" onclick="window.location.href='php/logout.php'">Sair</button>
        </div>
      </div>
    <?php else: ?>
      <div class="usuario-logado">
        <button onclick="window.location.href='login.html'" class="botao-login">Fazer Login</button>
      </div>
    <?php endif; ?>
  </div>
</header>

<main>
    <button id="btnVoltar" role="menuitem" onclick="window.location.href='index.php?idusu=<?= (int)$idusu ?>'">
      ← Voltar
    </button>

  <h1>Resenhas de Jogos</h1>

  <div id="lista-resenhas" class="container-resenhas">
    <?php if (!empty($avaliacoes)): ?>
      <?php foreach ($avaliacoes as $resenha): ?>
        <div class="resenha-card">
          <h2><?= htmlspecialchars($resenha['NOMEJOGO']) ?></h2>

          <?php $nota = (int)$resenha['AVALIACAO']; ?>
          <div class="estrelas">
            <?php for ($i = 1; $i <= 5; $i++): ?>
              <?php if ($i <= $nota): ?>
                <span class="estrela cheia">★</span>
              <?php else: ?>
                <span class="estrela vazia">☆</span>
              <?php endif; ?>
            <?php endfor; ?>
          </div>

          <p><?= nl2br(htmlspecialchars($resenha['RECOMENDACAO'])) ?></p>

          <div class="botoes-acao">
  <button class="btn-editar" onclick="if(confirm('Tem certeza?')) window.location.href='editar_resenha.php?idAva=<?= $resenha['IDAVA'] ?>&idusu=<?= $idusu ?>'">Editar</button>
  <button class="btn-excluir" onclick="if(confirm('Tem certeza?')) window.location.href='php/excluir_resenha.php?idAva=<?= $resenha['IDAVA'] ?>&idusu=<?= $idusu ?>'">Excluir</button>
</div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p>Nenhuma resenha encontrada para este usuário.</p>
    <?php endif; ?>
  </div>
</main>

<script src="js/script.js"></script>
<script src="js/script_carrossel.js"></script>
</body>
</html>